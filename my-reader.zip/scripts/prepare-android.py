#!/usr/bin/env python3
"""Runs in CI right after `npx cap add android`.
Copies native code + resources, patches the manifest and gradle version."""
import glob
import os
import re
import shutil
import sys

BUILD = os.environ.get("BUILD_NUMBER", "1")
VERSION_CODE = os.environ.get("VERSION_CODE", BUILD)
VERSION_NAME = os.environ.get("VERSION_NAME", "1.0." + BUILD)

APP = "android/app"
MAIN = APP + "/src/main"
RES = MAIN + "/res"
PKG_DIR = MAIN + "/java/com/sctc/reader"


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


def die(msg):
    print("ERROR: " + msg)
    sys.exit(1)


# 1. native java ---------------------------------------------------------------
os.makedirs(PKG_DIR, exist_ok=True)
for name in os.listdir("native/java"):
    shutil.copy(os.path.join("native/java", name), os.path.join(PKG_DIR, name))
print("java files:", sorted(os.listdir(PKG_DIR)))

# 2. resources -----------------------------------------------------------------
for p in glob.glob(RES + "/drawable*/splash.png"):
    os.remove(p)
for d in sorted(os.listdir("android-res")):
    src = os.path.join("android-res", d)
    dst = os.path.join(RES, d)
    os.makedirs(dst, exist_ok=True)
    for f in os.listdir(src):
        shutil.copy(os.path.join(src, f), os.path.join(dst, f))
print("resources copied")

# 3. manifest ------------------------------------------------------------------
mp = MAIN + "/AndroidManifest.xml"
m = read(mp)

perms = [
    "android.permission.READ_EXTERNAL_STORAGE",
    "android.permission.MANAGE_EXTERNAL_STORAGE",
    "android.permission.REQUEST_INSTALL_PACKAGES",
]
add = ""
for p in perms:
    if p not in m:
        add += '    <uses-permission android:name="%s" />\n' % p
if add:
    if "</manifest>" not in m:
        die("manifest has no </manifest>")
    m = m.replace("</manifest>", add + "</manifest>", 1)

if "requestLegacyExternalStorage" not in m:
    if "<application" not in m:
        die("manifest has no <application")
    m = m.replace(
        "<application",
        '<application\n        android:requestLegacyExternalStorage="true"\n        android:largeHeap="true"',
        1,
    )

if "application/epub+zip" not in m:
    flt = """
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="content" />
                <data android:scheme="file" />
                <data android:mimeType="application/pdf" />
                <data android:mimeType="application/epub+zip" />
            </intent-filter>
"""
    if "</activity>" not in m:
        die("manifest has no </activity>")
    m = m.replace("</activity>", flt + "\n        </activity>", 1)
write(mp, m)
print("manifest patched")

# 4. gradle --------------------------------------------------------------------
gp = APP + "/build.gradle"
g = read(gp)
g, n1 = re.subn(r"versionCode\s+\d+", "versionCode " + VERSION_CODE, g, count=1)
g, n2 = re.subn(r'versionName\s+"[^"]*"', 'versionName "%s"' % VERSION_NAME, g, count=1)
if n1 != 1 or n2 != 1:
    die("could not patch versionCode/versionName in build.gradle")
if "checkReleaseBuilds" not in g:
    g += "\nandroid {\n    lint {\n        checkReleaseBuilds false\n        abortOnError false\n    }\n}\n"
write(gp, g)
print("gradle patched: versionCode", VERSION_CODE, "versionName", VERSION_NAME)

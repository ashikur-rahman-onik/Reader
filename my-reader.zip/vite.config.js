import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    target: 'es2019',
    chunkSizeWarningLimit: 4000,
    sourcemap: false
  }
});

// Home screen: library / recent / favorites with lazy thumbnails.
import { h, iconBtn, sheet, toast, fmtSize, fmtDate, bookTitle, dirName, row, debounce } from './ui.js';
import { icon } from './icons.js';
import { t, num } from './i18n.js';
import * as store from './store.js';
import * as native from './native.js';
import { getThumb, cancelThumb } from './thumbs.js';

const BATCH = 36;

function extType(path) {
  return /\.epub$/i.test(path) ? 'epub' : 'pdf';
}

function baseName(path) {
  const p = String(path || '').split('/');
  return p[p.length - 1] || path;
}

export class Home {
  constructor(app) {
    this.app = app;
    this.tab = 'library';
    this.query = '';
    this.searchOpen = false;
    this.access = true;
    this.scanning = false;
    this.items = [];
    this.rendered = 0;
    this.hidden = false;
    this.pendingThumbs = new Set();
    this._build();
    this.unsub = store.subscribe((what) => {
      if (this.hidden) return;
      if (what === 'favorites' || what === 'lib' || what === 'history') this.render();
    });
  }

  // ---------------------------------------------------------------- build
  _build() {
    const s = store.settings();
    this.searchInput = h('input', { class: 'search-input', type: 'search', placeholder: t('search.placeholder'), enterkeyhint: 'search' });
    this.searchInput.addEventListener('input', debounce(() => {
      this.query = this.searchInput.value.trim();
      this.render();
    }, 160));

    this.scanLine = h('div', { class: 'scan-line' });
    this.head = h(
      'header',
      { class: 'home-head glass' },
      h('div', { class: 'brand' },
        h('span', { class: 'brand-tile' }, h('img', { src: 'symbol.png', alt: '', class: 'brand-mark' })),
        h('span', { class: 'brand-name' }, t('app.name'))),
      h('div', { class: 'head-actions' },
        iconBtn('search', t('search.placeholder'), () => this.toggleSearch()),
        this.refreshBtn = iconBtn('refresh', t('scan.refresh'), () => this.startScan(true)),
        iconBtn('sliders', t('settings.title'), () => this.app.openSettings()))
    );
    this.searchBar = h('div', { class: 'searchbar' }, h('div', { class: 'search-field glass' }, h('span', { html: icon('search', 18) }), this.searchInput));

    this.permBox = h('div', { class: 'perm-box' });
    this.heroBox = h('div', { class: 'hero-box' });
    this.tabsEl = h('div', { class: 'tabs', role: 'tablist' });
    this.toolbar = h('div', { class: 'toolbar' });
    this.listEl = h('div', { class: 'cards ' + (s.view === 'list' ? 'list' : 'grid') });
    this.sentinel = h('div', { class: 'sentinel' });
    this.scroll = h('div', { class: 'home-scroll' }, this.permBox, this.heroBox, this.tabsEl, this.toolbar, this.listEl, this.sentinel);
    this.el = h('div', { class: 'home' }, this.head, this.searchBar, this.scanLine, this.scroll);

    this.thumbIO = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        const card = en.target;
        this.thumbIO.unobserve(card);
        this._loadThumb(card);
      });
    }, { root: this.scroll, rootMargin: '240px' });

    this.moreIO = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) this._appendMore();
    }, { root: this.scroll, rootMargin: '600px' });
    this.moreIO.observe(this.sentinel);

    this._renderTabs();
    this.render();
  }

  destroy() {
    this.unsub();
    this.thumbIO.disconnect();
    this.moreIO.disconnect();
    this.el.remove();
  }

  setHidden(v) {
    this.hidden = v;
    this.el.classList.toggle('is-hidden', v);
    if (!v) {
      const keep = this.rendered;
      const top = this.scroll.scrollTop;
      this.render(keep);
      this.scroll.scrollTop = top;
    }
  }

  // ---------------------------------------------------------------- tabs / toolbar
  _renderTabs() {
    const tabs = [
      { id: 'library', label: t('tab.library'), icon: 'book' },
      { id: 'recent', label: t('tab.recent'), icon: 'clock' },
      { id: 'favorites', label: t('tab.favorites'), icon: 'star' }
    ];
    this.tabsEl.textContent = '';
    tabs.forEach((tb) => {
      this.tabsEl.appendChild(
        h('button', {
          class: 'tab' + (this.tab === tb.id ? ' on' : ''), type: 'button', role: 'tab',
          onclick: () => { this.tab = tb.id; this._renderTabs(); this.render(); this.scroll.scrollTop = 0; }
        }, h('span', { html: icon(tb.icon, 18, tb.id === 'favorites' && this.tab === tb.id) }), h('span', null, tb.label))
      );
    });
  }

  _renderToolbar(count) {
    const s = store.settings();
    this.toolbar.textContent = '';
    const chips = h('div', { class: 'chips' });
    [['all', t('filter.all')], ['pdf', 'PDF'], ['epub', 'EPUB']].forEach(([v, label]) => {
      chips.appendChild(h('button', {
        class: 'chip' + (s.filter === v ? ' on' : ''), type: 'button',
        onclick: () => { store.setSetting('filter', v); this._renderToolbar(count); this.render(); }
      }, label));
    });
    const sorts = ['date', 'name', 'size'];
    const sortBtn = h('button', {
      class: 'chip ghost', type: 'button',
      onclick: () => {
        const cur = store.settings().sort;
        store.setSetting('sort', sorts[(sorts.indexOf(cur) + 1) % sorts.length]);
        this._renderToolbar(count);
        this.render();
      }
    }, t('sort.' + s.sort));
    const viewBtn = iconBtn(s.view === 'list' ? 'grid' : 'list', 'view', () => {
      store.setSetting('view', s.view === 'list' ? 'grid' : 'list');
      this.listEl.className = 'cards ' + (store.settings().view === 'list' ? 'list' : 'grid');
      this._renderToolbar(count);
      this.render();
    }, 'sm');
    this.toolbar.appendChild(chips);
    this.toolbar.appendChild(h('div', { class: 'tool-right' }, this.tab === 'recent' ? null : sortBtn, viewBtn));
  }

  toggleSearch() {
    this.searchOpen = !this.searchOpen;
    this.searchBar.classList.toggle('open', this.searchOpen);
    if (this.searchOpen) {
      setTimeout(() => this.searchInput.focus(), 120);
    } else {
      this.searchInput.value = '';
      this.query = '';
      this.render();
    }
  }

  // ---------------------------------------------------------------- data
  _collect() {
    const s = store.settings();
    const lib = store.getLib().files;
    const byPath = new Map(lib.map((f) => [f.path, f]));
    let list;
    if (this.tab === 'library') {
      list = lib.slice();
    } else if (this.tab === 'recent') {
      list = store.recentList().map((hh) => byPath.get(hh.path) || { path: hh.path, name: hh.name || baseName(hh.path), type: hh.type || extType(hh.path), size: hh.size || 0, modified: 0 });
    } else {
      const hist = new Map(store.recentList().map((hh) => [hh.path, hh]));
      list = store.favoritePaths().map((p) => {
        const f = byPath.get(p);
        if (f) return f;
        const hh = hist.get(p);
        return { path: p, name: hh ? hh.name : baseName(p), type: hh ? hh.type : extType(p), size: hh ? hh.size : 0, modified: 0 };
      });
    }
    if (s.filter !== 'all') list = list.filter((f) => f.type === s.filter);
    if (this.query) {
      const q = this.query.toLowerCase();
      list = list.filter((f) => f.name.toLowerCase().includes(q));
    }
    if (this.tab !== 'recent') {
      if (s.sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
      else if (s.sort === 'size') list.sort((a, b) => (b.size || 0) - (a.size || 0));
      else list.sort((a, b) => (b.modified || 0) - (a.modified || 0));
    }
    return list;
  }

  // ---------------------------------------------------------------- render
  render(keep) {
    if (this.hidden) return;
    this.pendingThumbs.forEach((f) => cancelThumb(f));
    this.pendingThumbs.clear();
    this.thumbIO.disconnect();
    this.items = this._collect();
    this.rendered = 0;
    this.listEl.textContent = '';
    this._renderPermission();
    this._renderHero();
    this._renderToolbar(this.items.length);
    if (!this.items.length) {
      this.listEl.appendChild(this._emptyState());
      return;
    }
    this._appendMore();
    while (keep && this.rendered < Math.min(keep, this.items.length)) this._appendMore();
  }

  _appendMore() {
    if (this.hidden || this.rendered >= this.items.length) return;
    const end = Math.min(this.items.length, this.rendered + BATCH);
    const frag = document.createDocumentFragment();
    for (let i = this.rendered; i < end; i++) {
      const card = this._card(this.items[i]);
      card.style.setProperty('--i', String(Math.min(i - this.rendered, 12)));
      frag.appendChild(card);
    }
    this.rendered = end;
    this.listEl.appendChild(frag);
  }

  _emptyState() {
    let title = t('empty.library');
    let hint = t('empty.library.hint');
    let ic = 'book';
    if (this.query) { title = t('empty.search', { q: this.query }); hint = ''; ic = 'search'; }
    else if (this.tab === 'recent') { title = t('empty.recent'); hint = ''; ic = 'clock'; }
    else if (this.tab === 'favorites') { title = t('empty.fav'); hint = ''; ic = 'star'; }
    else if (this.scanning) { title = t('scan.running'); hint = ''; }
    return h('div', { class: 'empty' }, h('div', { class: 'empty-icon', html: icon(ic, 34) }), h('div', { class: 'empty-title' }, title), hint ? h('div', { class: 'empty-hint' }, hint) : null);
  }

  _renderPermission() {
    this.permBox.textContent = '';
    if (this.access) return;
    this.permBox.appendChild(
      h('div', { class: 'perm-card glass' },
        h('div', { class: 'perm-icon', html: icon('lock', 26) }),
        h('div', { class: 'perm-text' }, h('div', { class: 'perm-title' }, t('perm.title')), h('div', { class: 'perm-body' }, t('perm.body'))),
        h('div', { class: 'perm-actions' },
          h('button', { class: 'btn primary', type: 'button', onclick: () => this.app.requestAccess() }, t('perm.btn')),
          h('button', { class: 'btn ghost', type: 'button', onclick: () => this.app.recheckAccess() }, t('perm.check'))))
    );
  }

  _renderHero() {
    this.heroBox.textContent = '';
    if (this.tab !== 'library' || this.query) return;
    const last = store.recentList().find((e) => (e.progress || 0) < 0.995);
    if (!last) return;
    const lib = store.getLib().files.find((f) => f.path === last.path);
    const file = lib || { path: last.path, name: last.name || baseName(last.path), type: last.type || extType(last.path), size: last.size || 0, modified: 0 };
    const pct = Math.round((last.progress || 0) * 100);
    const thumb = h('div', { class: 'hero-thumb' }, h('span', { class: 'ph', html: icon(file.type === 'epub' ? 'book' : 'file', 26) }));
    thumb.__file = file;
    const card = h('div', { class: 'hero glass', onclick: () => this.app.openFile(file) },
      thumb,
      h('div', { class: 'hero-info' },
        h('div', { class: 'hero-kicker' }, t('continue')),
        h('div', { class: 'hero-title' }, bookTitle(file.name)),
        h('div', { class: 'hero-prog' }, h('i', { style: { width: Math.max(2, pct) + '%' } })),
        h('div', { class: 'hero-sub' }, t('progress', { p: num(pct) }))),
      h('button', { class: 'btn primary sm', type: 'button' }, t('continue.btn')));
    this.heroBox.appendChild(card);
    this._attachThumb(thumb, file);
  }

  _card(file) {
    const hist = store.getHistory(file.path);
    const pct = hist && hist.progress ? Math.round(hist.progress * 100) : 0;
    const fav = store.isFav(file.path);
    const thumb = h('div', { class: 'thumb' },
      h('span', { class: 'ph', html: icon(file.type === 'epub' ? 'book' : 'file', 30) }),
      h('span', { class: 'badge ' + file.type }, file.type === 'epub' ? 'EPUB' : 'PDF'),
      pct > 0 ? h('span', { class: 'ribbon' }, h('i', { style: { width: pct + '%' } })) : null,
      h('button', {
        class: 'fav-btn' + (fav ? ' on' : ''), type: 'button', 'aria-label': t('action.fav'),
        onclick: (e) => { e.stopPropagation(); store.toggleFav(file.path); },
        html: icon('star', 18, fav)
      }));
    const sub = pct > 0 ? t('progress', { p: num(pct) }) : fmtSize(file.size) + (dirName(file.path) ? ' · ' + dirName(file.path) : '');
    const card = h('div', { class: 'card', onclick: () => this.app.openFile(file) },
      thumb,
      h('div', { class: 'card-info' },
        h('div', { class: 'card-title' }, bookTitle(file.name)),
        h('div', { class: 'card-sub' }, sub)),
      h('button', { class: 'more-btn', type: 'button', 'aria-label': t('reader.more'), onclick: (e) => { e.stopPropagation(); this.openActions(file); }, html: icon('more', 20) }));
    card.__file = file;
    card.__thumb = thumb;
    this.thumbIO.observe(card);
    return card;
  }

  _attachThumb(thumb, file) {
    const io = new IntersectionObserver((entries, obs) => {
      if (entries.some((e) => e.isIntersecting)) {
        obs.disconnect();
        this._setThumb(thumb, file);
      }
    });
    io.observe(thumb);
  }

  _loadThumb(card) {
    this._setThumb(card.__thumb, card.__file);
  }

  _setThumb(thumbEl, file) {
    this.pendingThumbs.add(file);
    getThumb(file).then((url) => {
      this.pendingThumbs.delete(file);
      if (!url || !thumbEl.isConnected) return;
      thumbEl.style.backgroundImage = 'url("' + url + '")';
      thumbEl.classList.add('has-img');
    });
  }

  // ---------------------------------------------------------------- actions
  openActions(file) {
    const fav = store.isFav(file.path);
    const inHistory = !!store.getHistory(file.path);
    let sh = null;
    const item = (ic, label, fn) => h('button', { class: 'list-item', type: 'button', onclick: () => { sh.close(); fn(); } }, h('span', { html: icon(ic, 20) }), h('span', { class: 'li-title' }, label));
    const body = h('div', { class: 'list-body' },
      item('book', t('action.open'), () => this.app.openFile(file)),
      item('star', fav ? t('action.unfav') : t('action.fav'), () => { store.toggleFav(file.path); this.render(); }),
      item('share', t('action.share'), async () => { try { await native.shareFile(file.path, bookTitle(file.name)); } catch (e) { toast(t('toast.shareFailed')); } }),
      item('info', t('action.details'), () => this.showDetails(file)),
      inHistory ? item('trash', t('action.removeHistory'), () => { store.removeHistory(file.path); this.render(); }) : null);
    sh = sheet({ title: bookTitle(file.name), body });
  }

  showDetails(file) {
    const hist = store.getHistory(file.path);
    sheet({
      title: t('action.details'),
      body: h('div', { class: 'rows' },
        row(t('details.type'), h('span', { class: 'val' }, file.type === 'epub' ? 'EPUB' : 'PDF')),
        hist && hist.total ? row(t('details.pages'), h('span', { class: 'val' }, num(hist.total))) : null,
        row(t('details.size'), h('span', { class: 'val' }, fmtSize(file.size))),
        file.modified ? row(t('details.modified'), h('span', { class: 'val' }, fmtDate(file.modified))) : null,
        row(t('details.path'), h('span', { class: 'val path' }, file.path)))
    });
  }

  // ---------------------------------------------------------------- scanning / access
  setAccess(granted) {
    this.access = !!granted;
    this._renderPermission();
  }

  async startScan(manual) {
    if (this.scanning) return;
    if (!this.access) {
      if (manual) toast(t('toast.noAccess'));
      return;
    }
    this.scanning = true;
    this.refreshBtn.classList.add('spin');
    this.scanLine.classList.add('on');
    this.scanLine.textContent = t('scan.running');
    try {
      const files = await native.scanFiles();
      store.setLib(files);
      this.scanLine.textContent = t('scan.found', { n: num(files.length) });
    } catch (e) {
      this.scanLine.textContent = '';
    }
    this.scanning = false;
    this.refreshBtn.classList.remove('spin');
    setTimeout(() => this.scanLine.classList.remove('on'), 1600);
    this.render();
  }

  handleBack() {
    if (this.searchOpen) {
      this.toggleSearch();
      return true;
    }
    if (this.tab !== 'library') {
      this.tab = 'library';
      this._renderTabs();
      this.render();
      return true;
    }
    return false;
  }
}

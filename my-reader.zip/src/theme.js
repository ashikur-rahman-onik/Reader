// Applies the app theme (dark / light / system) and tints Android system bars.
import * as store from './store.js';
import * as native from './native.js';

const BG = { dark: '#070d24', light: '#eef3ff' };

export function resolveTheme() {
  const pref = store.settings().theme;
  if (pref === 'system') {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }
  return pref === 'light' ? 'light' : 'dark';
}

export function applyTheme() {
  const th = resolveTheme();
  document.documentElement.dataset.theme = th;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', BG[th]);
  native.setBars(BG[th], th === 'light');
}

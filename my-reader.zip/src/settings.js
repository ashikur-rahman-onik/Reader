// Settings sheet.
import { h, sheet, toggle, segmented, row, toast } from './ui.js';
import { t } from './i18n.js';
import * as store from './store.js';
import * as native from './native.js';
import { applyTheme } from './theme.js';
import { manualCheck, updateRepo } from './updater.js';
import { idbClear } from './idb.js';
import { clearThumbMemory } from './thumbs.js';

export async function openSettings(app) {
  const s = store.settings();
  const info = await native.getAppInfo();
  const repoInput = h('input', { class: 'field small', type: 'text', value: store.settings().updateRepo || '', placeholder: updateRepo() || 'owner/repo', autocapitalize: 'none', spellcheck: 'false' });
  repoInput.addEventListener('change', () => {
    store.setSetting('updateRepo', repoInput.value.trim());
    toast(t('common.save'), 1000);
  });

  const body = h(
    'div',
    { class: 'rows' },
    h('div', { class: 'group-title' }, t('settings.app')),
    row(t('settings.language'), segmented(
      [{ value: 'bn', label: 'বাংলা' }, { value: 'en', label: 'English' }],
      s.lang,
      (v) => { store.setSetting('lang', v); app.rebuild(); sh.close(); })),
    row(t('settings.theme'), segmented(
      [{ value: 'dark', label: t('settings.dark') }, { value: 'light', label: t('settings.light') }, { value: 'system', label: t('settings.system') }],
      s.theme,
      (v) => { store.setSetting('theme', v); applyTheme(); })),
    h('div', { class: 'group-title' }, t('settings.reading')),
    row(t('settings.curlDefault'), toggle(s.curl, (v) => store.setSetting('curl', v))),
    row(t('settings.speed'), segmented(
      [{ value: 'fast', label: t('settings.fast') }, { value: 'normal', label: t('settings.normal') }, { value: 'slow', label: t('settings.slow') }],
      s.speed,
      (v) => store.setSetting('speed', v))),
    row(t('settings.keepAwake'), toggle(s.keepAwake, (v) => store.setSetting('keepAwake', v))),
    row(t('settings.immersive'), toggle(s.immersive, (v) => store.setSetting('immersive', v))),
    h('div', { class: 'group-title' }, t('settings.checkUpdate')),
    row(t('settings.autoUpdate'), toggle(s.autoUpdate, (v) => store.setSetting('autoUpdate', v))),
    row(t('settings.updateSource'), repoInput),
    h('div', { class: 'btn-row' },
      h('button', { class: 'btn primary', type: 'button', onclick: () => manualCheck() }, t('settings.checkUpdate')),
      h('button', { class: 'btn ghost', type: 'button', onclick: async () => { await idbClear(); clearThumbMemory(); toast(t('settings.cleared')); app.refreshHome(); } }, t('settings.clearCache'))),
    h('div', { class: 'about' },
      h('img', { src: 'logo-full.png', alt: 'My Reader', class: 'about-logo' }),
      h('div', { class: 'about-ver' }, t('settings.version', { v: info.versionName || '1.0' })))
  );
  const sh = sheet({ title: t('settings.title'), body, tall: true });
}

// Bridge to the native Android plugin (with harmless fallbacks for a normal browser).
import { Capacitor, registerPlugin } from '@capacitor/core';
import { App } from '@capacitor/app';

export const isNative = Capacitor.isNativePlatform();
const Plugin = isNative ? registerPlugin('MyReaderNative') : null;

export function b64ToBytes(b64) {
  const bin = atob(b64);
  const len = bin.length;
  const out = new Uint8Array(len);
  for (let i = 0; i < len; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export async function hasAccess() {
  if (!Plugin) return true;
  try {
    const r = await Plugin.hasAccess();
    return !!r.granted;
  } catch (e) {
    return false;
  }
}

export async function requestAccess() {
  if (!Plugin) return;
  await Plugin.requestAccess();
}

export async function scanFiles() {
  if (!Plugin) return [];
  const r = await Plugin.scanFiles();
  return Array.isArray(r.files) ? r.files : [];
}

export async function statFile(path) {
  if (!Plugin) return { exists: false, size: 0 };
  try {
    const r = await Plugin.statFile({ path });
    return { exists: !!r.exists, size: Number(r.size) || 0 };
  } catch (e) {
    return { exists: false, size: 0 };
  }
}

export async function readChunk(path, offset, length) {
  if (!Plugin) throw new Error('native unavailable');
  const r = await Plugin.readChunk({ path, offset, length });
  return r.data ? b64ToBytes(r.data) : new Uint8Array(0);
}

// Reads a whole file into one Uint8Array (used for small PDFs and EPUBs).
export async function readWholeFile(path, size, onProgress) {
  const total = size > 0 ? size : (await statFile(path)).size;
  const out = new Uint8Array(total);
  const CHUNK = 2 * 1024 * 1024;
  let pos = 0;
  while (pos < total) {
    const want = Math.min(CHUNK, total - pos);
    const part = await readChunk(path, pos, want);
    if (!part.length) break;
    out.set(part, pos);
    pos += part.length;
    if (onProgress) onProgress(pos / total);
  }
  if (pos < total) return out.subarray(0, pos);
  return out;
}

export async function consumePendingOpen() {
  if (!Plugin) return null;
  try {
    const r = await Plugin.consumePendingOpen();
    return r && r.path ? r : null;
  } catch (e) {
    return null;
  }
}

export async function setBars(color, light) {
  if (!Plugin) return;
  try {
    await Plugin.setBars({ color, light: !!light });
  } catch (e) {
    /* ignore */
  }
}

export async function setImmersive(enabled) {
  if (!Plugin) return;
  try {
    await Plugin.setImmersive({ enabled: !!enabled });
  } catch (e) {
    /* ignore */
  }
}

export async function setKeepAwake(enabled) {
  if (!Plugin) return;
  try {
    await Plugin.setKeepAwake({ enabled: !!enabled });
  } catch (e) {
    /* ignore */
  }
}

export async function shareFile(path, title) {
  if (!Plugin) throw new Error('share unavailable');
  await Plugin.shareFile({ path, title: title || '' });
}

export async function getAppInfo() {
  if (!Plugin) return { versionName: 'dev', versionCode: 0 };
  try {
    const r = await Plugin.getAppInfo();
    return { versionName: String(r.versionName || ''), versionCode: Number(r.versionCode) || 0 };
  } catch (e) {
    return { versionName: '', versionCode: 0 };
  }
}

export async function downloadAndInstall(url, onProgress) {
  if (!Plugin) throw new Error('install unavailable');
  let handle = null;
  try {
    handle = await Plugin.addListener('updateProgress', (p) => {
      if (onProgress) onProgress(Number(p.received) || 0, Number(p.total) || 0);
    });
    return await Plugin.downloadAndInstall({ url });
  } finally {
    if (handle) handle.remove();
  }
}

export function onOpenIntent(cb) {
  if (!Plugin) return () => {};
  let handle = null;
  Plugin.addListener('openIntent', cb).then((h) => {
    handle = h;
  });
  return () => handle && handle.remove();
}

export function onResume(cb) {
  if (!isNative) return () => {};
  let handle = null;
  App.addListener('appStateChange', (s) => {
    if (s && s.isActive) cb();
  }).then((h) => {
    handle = h;
  });
  return () => handle && handle.remove();
}

export function onBackButton(cb) {
  if (!isNative) return () => {};
  let handle = null;
  App.addListener('backButton', cb).then((h) => {
    handle = h;
  });
  return () => handle && handle.remove();
}

export function exitApp() {
  if (isNative) App.exitApp();
}

// Pointer-gesture controller: tap zones, double-tap, pinch-zoom, pan and horizontal swipe.
// It works on a "zoom target" (an absolutely positioned element of known size) when one is set.
import { clamp } from './ui.js';

const TAP_MOVE = 10;
const TAP_TIME = 350;
const DOUBLE_TAP_MS = 300;
const SINGLE_TAP_DELAY = 260;

export class Gestures {
  // opts: { swipe, maxScale, onTap(zone), onDoubleTap(x,y), onSwipeMove(dx), onSwipeEnd(dx,vx), onZoomSettle(scale) }
  constructor(host, opts) {
    this.host = host;
    this.o = opts || {};
    this.maxScale = this.o.maxScale || 5;
    this.pointers = new Map();
    this.gesture = null;
    this.target = null;
    this.scale = 1;
    this.tx = 0;
    this.ty = 0;
    this.hw = 1;
    this.hh = 1;
    this.lastTap = null;
    this.tapTimer = null;
    this.enabled = true;

    this._down = this._down.bind(this);
    this._move = this._move.bind(this);
    this._up = this._up.bind(this);
    this._cancel = this._cancel.bind(this);
    host.addEventListener('pointerdown', this._down);
    host.addEventListener('pointermove', this._move);
    host.addEventListener('pointerup', this._up);
    host.addEventListener('pointercancel', this._cancel);
  }

  destroy() {
    this.host.removeEventListener('pointerdown', this._down);
    this.host.removeEventListener('pointermove', this._move);
    this.host.removeEventListener('pointerup', this._up);
    this.host.removeEventListener('pointercancel', this._cancel);
    if (this.tapTimer) clearTimeout(this.tapTimer);
    this.tapTimer = null;
  }

  get zoomed() {
    return !!this.target && this.scale > 1.02;
  }

  _measure() {
    const r = this.host.getBoundingClientRect();
    this.hw = r.width || 1;
    this.hh = r.height || 1;
    return r;
  }

  _local(e) {
    const r = this.host.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  // ---- zoom target management
  setTarget(el, w, h) {
    this.target = { el, w, h };
    el.style.position = 'absolute';
    el.style.left = '0';
    el.style.top = '0';
    el.style.width = w + 'px';
    el.style.height = h + 'px';
    el.style.transformOrigin = '0 0';
    this.scale = 1;
    this._measure();
    this._fit();
    this._apply(false);
  }

  clearTarget() {
    this.target = null;
    this.scale = 1;
  }

  // Re-measure the host (after rotation/resize) and re-fit when not zoomed.
  layout() {
    this._measure();
    if (!this.target) return;
    if (this.scale <= 1.02) {
      this.scale = 1;
      this._fit();
    } else {
      this._clamp();
    }
    this._apply(false);
  }

  _fit() {
    if (!this.target) return;
    this.tx = (this.hw - this.target.w) / 2;
    this.ty = (this.hh - this.target.h) / 2;
  }

  _clamp() {
    if (!this.target) return;
    const W = this.target.w * this.scale;
    const H = this.target.h * this.scale;
    this.tx = W <= this.hw ? (this.hw - W) / 2 : clamp(this.tx, this.hw - W, 0);
    this.ty = H <= this.hh ? (this.hh - H) / 2 : clamp(this.ty, this.hh - H, 0);
  }

  _apply(animate) {
    if (!this.target) return;
    const el = this.target.el;
    el.style.transition = animate ? 'transform 0.24s cubic-bezier(0.2, 0.8, 0.2, 1)' : 'none';
    el.style.transform = 'translate3d(' + this.tx + 'px,' + this.ty + 'px,0) scale(' + this.scale + ')';
  }

  zoomAt(s, x, y, animate) {
    if (!this.target) return;
    const ns = clamp(s, 1, this.maxScale);
    const cx = (x - this.tx) / this.scale;
    const cy = (y - this.ty) / this.scale;
    this.scale = ns;
    this.tx = x - cx * ns;
    this.ty = y - cy * ns;
    this._clamp();
    this._apply(animate !== false);
    this._notifySettle(animate !== false ? 250 : 0);
  }

  reset(animate) {
    if (!this.target) return;
    this.scale = 1;
    this._fit();
    this._apply(animate !== false);
    this._notifySettle(animate !== false ? 250 : 0);
  }

  _notifySettle(delay) {
    const fire = () => {
      if (this.o.onZoomSettle) this.o.onZoomSettle(this.scale);
    };
    if (delay) setTimeout(fire, delay);
    else fire();
  }

  // ---- pointer handling
  _down(e) {
    if (!this.enabled) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    try {
      this.host.setPointerCapture(e.pointerId);
    } catch (err) {
      /* ignore */
    }
    this._measure();
    const p = this._local(e);
    this.pointers.set(e.pointerId, p);
    if (this.pointers.size === 1) {
      this.gesture = {
        startX: p.x, startY: p.y, startT: performance.now(),
        lastX: p.x, lastY: p.y, lastT: performance.now(),
        moved: false, multi: false, swiping: false, vx: 0
      };
    } else if (this.gesture) {
      this.gesture.multi = true;
      if (this.tapTimer) {
        clearTimeout(this.tapTimer);
        this.tapTimer = null;
      }
      this._pinchStart();
    }
  }

  _pinchStart() {
    const pts = Array.from(this.pointers.values());
    if (pts.length < 2) return;
    const a = pts[0];
    const b = pts[1];
    this.p0 = {
      d: Math.max(1, Math.hypot(a.x - b.x, a.y - b.y)),
      scale: this.scale, tx: this.tx, ty: this.ty,
      mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2
    };
  }

  _move(e) {
    if (!this.pointers.has(e.pointerId)) return;
    const p = this._local(e);
    this.pointers.set(e.pointerId, p);
    const g = this.gesture;
    if (!g) return;

    if (this.pointers.size >= 2) {
      if (!this.target || !this.p0) return;
      const pts = Array.from(this.pointers.values());
      const a = pts[0];
      const b = pts[1];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const mx = (a.x + b.x) / 2;
      const my = (a.y + b.y) / 2;
      const ns = clamp((this.p0.scale * d) / this.p0.d, 0.7, this.maxScale);
      const cx = (this.p0.mx - this.p0.tx) / this.p0.scale;
      const cy = (this.p0.my - this.p0.ty) / this.p0.scale;
      this.scale = ns;
      this.tx = mx - cx * ns;
      this.ty = my - cy * ns;
      this._apply(false);
      g.moved = true;
      return;
    }

    if (g.multi) {
      // one finger left after a pinch: pan only
      if (this.target && this.scale > 1.02) {
        this.tx += p.x - g.lastX;
        this.ty += p.y - g.lastY;
        this._clamp();
        this._apply(false);
      }
      g.lastX = p.x;
      g.lastY = p.y;
      return;
    }

    const dx = p.x - g.startX;
    const dy = p.y - g.startY;
    if (!g.moved && Math.hypot(dx, dy) > TAP_MOVE) g.moved = true;
    const now = performance.now();
    const dt = Math.max(1, now - g.lastT);
    g.vx = (p.x - g.lastX) / dt;

    if (this.target && this.scale > 1.02) {
      this.tx += p.x - g.lastX;
      this.ty += p.y - g.lastY;
      this._clamp();
      this._apply(false);
    } else if (this.o.swipe && g.moved) {
      if (!g.swiping && Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) * 1.2) g.swiping = true;
      if (g.swiping && this.o.onSwipeMove) this.o.onSwipeMove(dx);
    }
    g.lastX = p.x;
    g.lastY = p.y;
    g.lastT = now;
  }

  _up(e) {
    if (!this.pointers.has(e.pointerId)) return;
    const p = this._local(e);
    this.pointers.delete(e.pointerId);
    try {
      this.host.releasePointerCapture(e.pointerId);
    } catch (err) {
      /* ignore */
    }
    const g = this.gesture;
    if (this.pointers.size > 0) {
      if (g) {
        const rem = Array.from(this.pointers.values())[0];
        g.lastX = rem.x;
        g.lastY = rem.y;
      }
      return;
    }
    if (!g) return;
    this.gesture = null;
    this.p0 = null;

    if (g.multi) {
      this._settle();
      return;
    }
    if (g.swiping) {
      if (this.o.onSwipeEnd) this.o.onSwipeEnd(p.x - g.startX, g.vx);
      return;
    }
    if (!g.moved && performance.now() - g.startT < TAP_TIME) {
      this._tap(g.startX, g.startY);
    } else if (this.o.swipe && g.moved && this.o.onSwipeEnd && !this.zoomed) {
      // slow drag that never became a horizontal swipe: make sure any visual offset is reset
      this.o.onSwipeEnd(0, 0);
    }
  }

  _cancel(e) {
    this.pointers.delete(e.pointerId);
    if (this.pointers.size === 0) {
      const g = this.gesture;
      this.gesture = null;
      this.p0 = null;
      if (g && g.swiping && this.o.onSwipeEnd) this.o.onSwipeEnd(0, 0);
      this._settle();
    }
  }

  _settle() {
    if (!this.target) return;
    if (this.scale < 1.03) {
      this.scale = 1;
      this._fit();
      this._apply(true);
    } else {
      this._clamp();
      this._apply(true);
    }
    this._notifySettle(250);
  }

  _zone(x) {
    const f = x / this.hw;
    if (f < 0.28) return 'L';
    if (f > 0.72) return 'R';
    return 'C';
  }

  _tap(x, y) {
    const now = performance.now();
    const zone = this._zone(x);
    const prev = this.lastTap;
    const isDouble =
      prev && now - prev.t < DOUBLE_TAP_MS && Math.hypot(x - prev.x, y - prev.y) < 48 &&
      (this.zoomed || (zone === 'C' && prev.zone === 'C'));

    if (isDouble) {
      this.lastTap = null;
      if (this.tapTimer) {
        clearTimeout(this.tapTimer);
        this.tapTimer = null;
      }
      if (this.target) {
        if (this.zoomed) this.reset(true);
        else this.zoomAt(2.5, x, y, true);
      } else if (this.o.onDoubleTap) {
        this.o.onDoubleTap(x, y);
      }
      return;
    }

    this.lastTap = { t: now, x, y, zone };
    if (this.zoomed) {
      this._delayedTap('C');
    } else if (zone === 'C') {
      this._delayedTap('C');
    } else {
      this.lastTap = null;
      if (this.o.onTap) this.o.onTap(zone);
    }
  }

  _delayedTap(zone) {
    if (this.tapTimer) clearTimeout(this.tapTimer);
    this.tapTimer = setTimeout(() => {
      this.tapTimer = null;
      if (this.o.onTap) this.o.onTap(zone);
    }, SINGLE_TAP_DELAY);
  }
}

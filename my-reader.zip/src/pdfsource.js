// PDF loading (pdf.js), page-image cache/render queue, text search and outline helpers.
import { readChunk, readWholeFile, statFile } from './native.js';

let libPromise = null;

export function loadPdfjs() {
  if (!libPromise) {
    libPromise = (async () => {
      const mod = await import('pdfjs-dist/legacy/build/pdf.js');
      const lib = mod && mod.getDocument ? mod : mod.default;
      const worker = await import('pdfjs-dist/legacy/build/pdf.worker.min.js?url');
      lib.GlobalWorkerOptions.workerSrc = worker.default;
      return lib;
    })();
    libPromise.catch(() => {
      libPromise = null;
    });
  }
  return libPromise;
}

function makeTransport(lib, size, first, path) {
  class FileTransport extends lib.PDFDataRangeTransport {
    requestDataRange(begin, end) {
      readChunk(path, begin, end - begin)
        .then((buf) => this.onDataRange(begin, buf))
        .catch(() => {});
    }
  }
  return new FileTransport(size, first);
}

// opts: { wholeLimit, askPassword(reason) -> Promise<string|null> }
export async function openPdfFile(path, opts) {
  const o = opts || {};
  const lib = await loadPdfjs();
  const st = await statFile(path);
  if (!st.exists) {
    const e = new Error('missing');
    e.code = 'MISSING';
    throw e;
  }
  const wholeLimit = o.wholeLimit !== undefined ? o.wholeLimit : 24 * 1024 * 1024;
  const params = { isEvalSupported: false, verbosity: 0 };
  if (st.size <= wholeLimit) {
    params.data = await readWholeFile(path, st.size);
  } else {
    const first = await readChunk(path, 0, Math.min(st.size, 262144));
    params.range = makeTransport(lib, st.size, first, path);
    params.length = st.size;
    params.rangeChunkSize = 262144;
    params.disableAutoFetch = true;
    params.disableStream = true;
  }
  const task = lib.getDocument(params);
  let cancelled = false;
  if (o.askPassword) {
    task.onPassword = (update, reason) => {
      o.askPassword(reason).then((pw) => {
        if (pw === null || pw === undefined) {
          cancelled = true;
          task.destroy();
        } else {
          update(pw);
        }
      });
    };
  }
  try {
    const pdf = await task.promise;
    return { pdf, size: st.size };
  } catch (err) {
    if (cancelled) {
      const e = new Error('cancelled');
      e.code = 'CANCELLED';
      throw e;
    }
    throw err;
  }
}

const MAX_PIXELS = 12 * 1000 * 1000;

function makeCanvas(w, h) {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(w));
  canvas.height = Math.max(1, Math.round(h));
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  return { canvas, ctx };
}

function toBlob(canvas, type, q) {
  return new Promise((resolve) => canvas.toBlob(resolve, type, q));
}

// Renders one page to a canvas at the requested pixel width (capped by MAX_PIXELS).
export async function renderPageCanvas(pdf, index, pixelWidth) {
  const page = await pdf.getPage(index + 1);
  try {
    const base = page.getViewport({ scale: 1 });
    let scale = pixelWidth / base.width;
    const pixels = base.width * scale * (base.height * scale);
    if (pixels > MAX_PIXELS) scale *= Math.sqrt(MAX_PIXELS / pixels);
    const vp = page.getViewport({ scale });
    const { canvas, ctx } = makeCanvas(vp.width, vp.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    return canvas;
  } finally {
    page.cleanup();
  }
}

export async function getPageRatio(pdf, index) {
  const page = await pdf.getPage(index + 1);
  const vp = page.getViewport({ scale: 1 });
  page.cleanup();
  return vp.width / vp.height;
}

// Cache of rendered page images (object URLs) with a small prioritised queue.
export class PageImages {
  constructor(pdf, opts) {
    this.pdf = pdf;
    this.width = opts.width;
    this.onReady = opts.onReady || null;
    this.onEvict = opts.onEvict || null;
    this.cache = new Map();
    this.pending = new Map();
    this.queue = [];
    this.active = 0;
    this.center = 0;
    this.destroyed = false;
  }

  peek(i) {
    const e = this.cache.get(i);
    return e ? e.url : null;
  }

  request(i) {
    if (this.destroyed || i < 0 || i >= this.pdf.numPages) return Promise.resolve(null);
    const hit = this.cache.get(i);
    if (hit) return Promise.resolve(hit.url);
    const p = this.pending.get(i);
    if (p) return p.promise;
    const entry = {};
    entry.promise = new Promise((resolve) => {
      entry.resolve = resolve;
    });
    this.pending.set(i, entry);
    this.queue.push(i);
    this._pump();
    return entry.promise;
  }

  _pump() {
    while (!this.destroyed && this.active < 2 && this.queue.length) {
      const c = this.center;
      this.queue.sort((a, b) => Math.abs(a - c) - Math.abs(b - c));
      const i = this.queue.shift();
      this._run(i);
    }
  }

  async _run(i) {
    this.active++;
    const entry = this.pending.get(i);
    let result = null;
    try {
      const canvas = await renderPageCanvas(this.pdf, i, this.width);
      const w = canvas.width;
      const h = canvas.height;
      const blob = await toBlob(canvas, 'image/jpeg', 0.92);
      canvas.width = 1;
      canvas.height = 1;
      if (blob) {
        const url = URL.createObjectURL(blob);
        if (this.destroyed) {
          URL.revokeObjectURL(url);
        } else {
          this.cache.set(i, { url, w, h });
          result = url;
          if (this.onReady) this.onReady(i, url, w, h);
        }
      }
    } catch (e) {
      result = null;
    } finally {
      this.active--;
      this.pending.delete(i);
      if (entry) entry.resolve(result);
      this._pump();
    }
  }

  // Keep pages near `c` (within `keep`), drop queued work and cached images far away.
  setCenter(c, keep) {
    this.center = c;
    this.queue = this.queue.filter((i) => {
      if (Math.abs(i - c) > keep) {
        const p = this.pending.get(i);
        this.pending.delete(i);
        if (p) p.resolve(null);
        return false;
      }
      return true;
    });
    for (const [i, e] of Array.from(this.cache.entries())) {
      if (Math.abs(i - c) > keep + 4) {
        this.cache.delete(i);
        URL.revokeObjectURL(e.url);
        if (this.onEvict) this.onEvict(i);
      }
    }
  }

  destroy() {
    this.destroyed = true;
    this.queue = [];
    this.pending.forEach((p) => p.resolve(null));
    this.pending.clear();
    this.cache.forEach((e) => URL.revokeObjectURL(e.url));
    this.cache.clear();
  }
}

// ------------------------------------------------------------------ outline
export async function getOutlineFlat(pdf) {
  let outline = null;
  try {
    outline = await pdf.getOutline();
  } catch (e) {
    outline = null;
  }
  const out = [];
  const walk = (items, depth) => {
    (items || []).forEach((it) => {
      out.push({ title: String(it.title || '').trim() || '—', depth, dest: it.dest });
      if (it.items && it.items.length && depth < 4) walk(it.items, depth + 1);
    });
  };
  walk(outline, 0);
  return out;
}

export async function destToPageIndex(pdf, dest) {
  try {
    let d = dest;
    if (typeof d === 'string') d = await pdf.getDestination(d);
    if (!Array.isArray(d) || !d.length) return null;
    const ref = d[0];
    if (ref && typeof ref === 'object') return await pdf.getPageIndex(ref);
    if (Number.isInteger(ref)) return ref;
  } catch (e) {
    return null;
  }
  return null;
}

// ------------------------------------------------------------------ search
function snippet(text, idx, len) {
  const start = Math.max(0, idx - 36);
  const end = Math.min(text.length, idx + len + 56);
  return (start > 0 ? '…' : '') + text.slice(start, end).trim() + (end < text.length ? '…' : '');
}

export async function searchPdf(pdf, query, hooks) {
  const q = query.toLowerCase();
  let found = 0;
  for (let i = 1; i <= pdf.numPages; i++) {
    if (hooks.isCancelled()) return;
    let page = null;
    try {
      page = await pdf.getPage(i);
      const tc = await page.getTextContent();
      const text = tc.items.map((it) => it.str).join(' ').replace(/\s+/g, ' ');
      const lower = text.toLowerCase();
      let idx = lower.indexOf(q);
      let n = 0;
      while (idx !== -1 && n < 3) {
        hooks.onResult({ page: i - 1, snippet: snippet(text, idx, q.length) });
        n++;
        found++;
        idx = lower.indexOf(q, idx + q.length);
      }
    } catch (e) {
      /* skip unreadable page */
    } finally {
      if (page) page.cleanup();
    }
    hooks.onProgress(i / pdf.numPages);
    if (found >= 300) break;
  }
}

// ------------------------------------------------------------------ thumbnail
export async function renderPdfThumb(path) {
  const { pdf } = await openPdfFile(path, { wholeLimit: 1.5 * 1024 * 1024 });
  try {
    const canvas = await renderPageCanvas(pdf, 0, 260);
    const url = canvas.toDataURL('image/jpeg', 0.8);
    canvas.width = 1;
    canvas.height = 1;
    return { url, pages: pdf.numPages };
  } finally {
    try {
      pdf.destroy();
    } catch (e) {
      /* ignore */
    }
  }
}

// Persistent app state in localStorage (settings, history, favorites, bookmarks, library cache).
const K = {
  settings: 'myreader.settings.v1',
  history: 'myreader.history.v1',
  favorites: 'myreader.favorites.v1',
  bookmarks: 'myreader.bookmarks.v1',
  lib: 'myreader.lib.v1',
  meta: 'myreader.meta.v1'
};

const DEFAULT_SETTINGS = {
  lang: 'bn',
  theme: 'dark', // dark | light | system
  curl: true,
  speed: 'normal', // fast | normal | slow
  keepAwake: true,
  immersive: true,
  autoUpdate: true,
  view: 'grid', // grid | list
  sort: 'date', // date | name | size
  filter: 'all', // all | pdf | epub
  pdfTheme: 'day', // day | sepia | night
  epubTheme: 'day',
  epubFont: 100,
  epubFamily: 'serif', // serif | sans | original
  epubLine: 1.6,
  epubMargin: 1, // 0 | 1 | 2
  updateRepo: ''
};

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const v = JSON.parse(raw);
    return v === null || v === undefined ? fallback : v;
  } catch (e) {
    return fallback;
  }
}

const data = {
  settings: Object.assign({}, DEFAULT_SETTINGS, read(K.settings, {})),
  history: read(K.history, {}),
  favorites: read(K.favorites, {}),
  bookmarks: read(K.bookmarks, {}),
  lib: read(K.lib, { files: [], scannedAt: 0 }),
  meta: read(K.meta, {})
};

if (typeof data.history !== 'object' || Array.isArray(data.history)) data.history = {};
if (typeof data.favorites !== 'object' || Array.isArray(data.favorites)) data.favorites = {};
if (typeof data.bookmarks !== 'object' || Array.isArray(data.bookmarks)) data.bookmarks = {};
if (!data.lib || !Array.isArray(data.lib.files)) data.lib = { files: [], scannedAt: 0 };

const timers = {};
const listeners = new Set();

function persist(name) {
  try {
    localStorage.setItem(K[name], JSON.stringify(data[name]));
  } catch (e) {
    /* storage full or blocked: ignore */
  }
}

function queue(name) {
  if (timers[name]) clearTimeout(timers[name]);
  timers[name] = setTimeout(() => {
    timers[name] = null;
    persist(name);
  }, 250);
}

function emit(what) {
  listeners.forEach((fn) => {
    try {
      fn(what);
    } catch (e) {
      /* listener errors must not break the store */
    }
  });
}

export function flush() {
  Object.keys(K).forEach((name) => {
    if (timers[name]) {
      clearTimeout(timers[name]);
      timers[name] = null;
      persist(name);
    }
  });
}

if (typeof window !== 'undefined') {
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flush();
  });
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

// ---- settings
export function settings() {
  return data.settings;
}
export function setSetting(key, value) {
  data.settings[key] = value;
  queue('settings');
  emit('settings');
}

// ---- library cache
export function getLib() {
  return data.lib;
}
export function setLib(files) {
  data.lib = { files, scannedAt: Date.now() };
  queue('lib');
  emit('lib');
}

// ---- history
export function getHistory(path) {
  return data.history[path] || null;
}
export function touchHistory(file) {
  const prev = data.history[file.path] || {};
  data.history[file.path] = Object.assign({}, prev, {
    path: file.path,
    name: file.name,
    type: file.type,
    size: file.size || prev.size || 0,
    lastOpened: Date.now()
  });
  queue('history');
  emit('history');
  return data.history[file.path];
}
export function updateProgress(path, patch) {
  const h = data.history[path];
  if (!h) return;
  Object.assign(h, patch);
  queue('history');
  emit('progress');
}
export function removeHistory(path) {
  delete data.history[path];
  queue('history');
  emit('history');
}
export function recentList() {
  return Object.values(data.history)
    .filter((h) => h && h.path)
    .sort((a, b) => (b.lastOpened || 0) - (a.lastOpened || 0));
}

// ---- favorites
export function isFav(path) {
  return !!data.favorites[path];
}
export function toggleFav(path) {
  if (data.favorites[path]) delete data.favorites[path];
  else data.favorites[path] = Date.now();
  queue('favorites');
  emit('favorites');
  return !!data.favorites[path];
}
export function favoritePaths() {
  return Object.keys(data.favorites);
}

// ---- bookmarks
export function getBookmarks(path) {
  return data.bookmarks[path] || [];
}
export function addBookmark(path, bm) {
  const list = data.bookmarks[path] || (data.bookmarks[path] = []);
  const item = Object.assign({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), ts: Date.now() }, bm);
  list.push(item);
  queue('bookmarks');
  emit('bookmarks');
  return item;
}
export function removeBookmark(path, id) {
  const list = data.bookmarks[path];
  if (!list) return;
  data.bookmarks[path] = list.filter((b) => b.id !== id);
  if (!data.bookmarks[path].length) delete data.bookmarks[path];
  queue('bookmarks');
  emit('bookmarks');
}

// ---- meta (misc small values: last update check etc.)
export function getMeta(key, fallback) {
  return data.meta[key] !== undefined ? data.meta[key] : fallback;
}
export function setMeta(key, value) {
  data.meta[key] = value;
  queue('meta');
}

// Lazy thumbnail generation with persistent cache and a single-lane queue.
import { idbGet, idbPut } from './idb.js';
import { renderPdfThumb } from './pdfsource.js';

const mem = new Map();
const queue = [];
let running = false;

function keyOf(f) {
  return f.path + '|' + (f.size || 0) + '|' + (f.modified || 0);
}

async function generate(f) {
  try {
    if (f.type === 'epub') {
      const m = await import('./epubsource.js');
      const r = await m.renderEpubThumb(f.path, f.size || 0);
      return r ? r.url : '';
    }
    const r = await renderPdfThumb(f.path);
    return r.url;
  } catch (e) {
    return '';
  }
}

async function pump() {
  if (running) return;
  running = true;
  while (queue.length) {
    const job = queue.shift();
    const key = keyOf(job.file);
    let url = mem.get(key);
    if (url === undefined) {
      url = await idbGet(key);
      if (url === null) {
        url = await generate(job.file);
        idbPut(key, url);
      }
      mem.set(key, url);
    }
    job.resolve(url || null);
  }
  running = false;
}

export function getThumb(file) {
  const key = keyOf(file);
  const hit = mem.get(key);
  if (hit !== undefined) return Promise.resolve(hit || null);
  return new Promise((resolve) => {
    queue.push({ file, resolve });
    pump();
  });
}

export function cancelThumb(file) {
  const i = queue.findIndex((j) => j.file === file);
  if (i >= 0) {
    const j = queue.splice(i, 1)[0];
    j.resolve(null);
  }
}

export function clearThumbMemory() {
  mem.clear();
}

// PDF reader: page-curl (page-flip) or flat swipe view, zoom, search, contents, bookmarks.
import { PageFlip } from 'page-flip';
import { h, iconBtn, sheet, dialog, toast, toggle, segmented, row, fmtSize, fmtDate, bookTitle, pushOverlay, popOverlay, debounce, clamp } from './ui.js';
import { icon } from './icons.js';
import { t, num } from './i18n.js';
import * as store from './store.js';
import * as native from './native.js';
import { createShell } from './shell.js';
import { Gestures } from './gestures.js';
import { openPdfFile, getPageRatio, PageImages, renderPageCanvas, getOutlineFlat, destToPageIndex, searchPdf } from './pdfsource.js';

const FLIP_TIME = { fast: 450, normal: 800, slow: 1200 };
const THEMES = ['day', 'sepia', 'night'];

// ------------------------------------------------------------------ one page "stage" (image + optional hi-res canvas)
class PageStage {
  constructor(index) {
    this.index = index;
    this.w = 0;
    this.h = 0;
    this.ratio = 0;
    this.token = 0;
    this.hi = null;
    this.img = h('img', { class: 'pf-img', draggable: 'false', alt: '' });
    this.el = h('div', { class: 'page-stage' }, this.img, h('div', { class: 'pf-spin' }));
  }

  setUrl(url) {
    this.img.src = url;
    this.el.classList.add('ready');
  }

  fit(hw, hh, ratio) {
    this.ratio = ratio;
    const w = Math.max(40, Math.min(hw, hh * ratio));
    this.w = Math.round(w);
    this.h = Math.round(w / ratio);
  }

  async renderHi(pdf, pixelWidth) {
    const my = ++this.token;
    try {
      const canvas = await renderPageCanvas(pdf, this.index, pixelWidth);
      if (my !== this.token) {
        canvas.width = 1;
        canvas.height = 1;
        return;
      }
      if (this.hi) this.hi.remove();
      canvas.className = 'hi';
      this.el.appendChild(canvas);
      this.hi = canvas;
    } catch (e) {
      /* keep the normal image */
    }
  }

  clearHi() {
    this.token++;
    if (this.hi) {
      this.hi.width = 1;
      this.hi.height = 1;
      this.hi.remove();
      this.hi = null;
    }
  }
}

// ------------------------------------------------------------------ page-curl view
class CurlView {
  constructor(r) {
    this.r = r;
    this.pf = null;
    this.pages = [];
    this.parent = null;
  }

  orientation() {
    try {
      return this.pf && this.pf.getOrientation() === 'landscape' ? 'landscape' : 'portrait';
    } catch (e) {
      return 'portrait';
    }
  }

  _applyOrientationPref() {
    const cw = this.parent.clientWidth || 1;
    const ch = this.parent.clientHeight || 1;
    const spread = cw / ch > 1.15;
    this.pf.getSettings().minWidth = spread ? 50 : Math.max(50, cw);
  }

  mount(start) {
    const r = this.r;
    this.parent = h('div', { class: 'curl-parent' });
    r.shell.stage.appendChild(this.parent);
    for (let i = 0; i < r.total; i++) {
      const img = h('img', { class: 'pf-img', draggable: 'false', alt: '' });
      const el = h('div', { class: 'pf-page' }, img, h('div', { class: 'pf-spin' }));
      el.dataset.density = 'soft';
      const url = r.images.peek(i);
      if (url) {
        img.src = url;
        el.classList.add('ready');
      }
      this.pages.push({ el, img });
    }
    const baseW = 600;
    this.pf = new PageFlip(this.parent, {
      width: baseW,
      height: Math.round(baseW / r.ratio),
      size: 'stretch',
      minWidth: 50,
      maxWidth: 5000,
      minHeight: 100,
      maxHeight: 9000,
      drawShadow: true,
      flippingTime: FLIP_TIME[store.settings().speed] || FLIP_TIME.normal,
      usePortrait: true,
      startZIndex: 0,
      autoSize: false,
      maxShadowOpacity: 0.5,
      showCover: false,
      mobileScrollSupport: false,
      clickEventForward: false,
      useMouseEvents: true,
      swipeDistance: 30,
      showPageCorners: false,
      disableFlipByClick: true,
      startPage: start
    });
    this._applyOrientationPref();
    this.pf.loadFromHTML(this.pages.map((p) => p.el));
    this.pf.on('flip', (e) => r.setPage(e.data, 'curl'));
    this.pf.on('changeOrientation', () => r.refreshLabel());
    r.setPage(start, 'curl');
  }

  current() {
    try {
      return this.pf.getCurrentPageIndex();
    } catch (e) {
      return this.r.page;
    }
  }

  next() {
    try {
      this.pf.flipNext('bottom');
    } catch (e) {
      /* ignore */
    }
  }

  prev() {
    try {
      this.pf.flipPrev('bottom');
    } catch (e) {
      /* ignore */
    }
  }

  goTo(i) {
    try {
      this.pf.turnToPage(clamp(i, 0, this.r.total - 1));
      this.r.setPage(this.pf.getCurrentPageIndex(), 'curl');
    } catch (e) {
      /* ignore */
    }
  }

  onImage(i, url) {
    const p = this.pages[i];
    if (!p) return;
    p.img.src = url;
    p.el.classList.add('ready');
  }

  onEvict(i) {
    const p = this.pages[i];
    if (!p) return;
    p.img.removeAttribute('src');
    p.el.classList.remove('ready');
  }

  relayout() {
    if (!this.pf) return;
    this._applyOrientationPref();
    try {
      this.pf.update();
    } catch (e) {
      /* ignore */
    }
    this.r.refreshLabel();
  }

  destroy() {
    try {
      if (this.pf) this.pf.destroy();
    } catch (e) {
      /* ignore */
    }
    if (this.parent) this.parent.remove();
    this.pf = null;
    this.pages = [];
  }
}

// ------------------------------------------------------------------ flat (swipe) view
class FlatView {
  constructor(r) {
    this.r = r;
    this.host = null;
    this.cur = null;
    this.index = 0;
    this.animating = false;
  }

  orientation() {
    return 'portrait';
  }

  mount(start) {
    this.host = h('div', { class: 'flat-host' });
    this.r.shell.stage.appendChild(this.host);
    this.show(start, 0, false, 0);
  }

  _makeSlide(i) {
    const stage = new PageStage(i);
    const slide = h('div', { class: 'flat-slide' }, stage.el);
    this.host.appendChild(slide);
    return { slide, stage, index: i };
  }

  _layout(s) {
    const rect = this.host.getBoundingClientRect();
    s.stage.fit(rect.width || 1, rect.height || 1, s.stage.ratio || this.r.ratio);
    s.stage.el.style.width = s.stage.w + 'px';
    s.stage.el.style.height = s.stage.h + 'px';
  }

  current() {
    return this.index;
  }

  show(i, dir, animate, offset) {
    const r = this.r;
    const idx = clamp(i, 0, r.total - 1);
    const next = this._makeSlide(idx);
    this._layout(next);
    const url = r.images.peek(idx);
    if (url) next.stage.setUrl(url);
    const old = this.cur;
    this.cur = next;
    this.index = idx;
    r.gestures.setTarget(next.stage.el, next.stage.w, next.stage.h);
    r.setPage(idx, 'flat');
    if (!old) return;
    const hw = this.host.clientWidth || 1;
    if (!animate || !dir) {
      old.slide.remove();
      old.stage.clearHi();
      return;
    }
    this.animating = true;
    next.slide.style.transition = 'none';
    next.slide.style.transform = 'translateX(' + (dir * hw + (offset || 0)) + 'px)';
    void next.slide.offsetWidth;
    const tr = 'transform 0.26s cubic-bezier(0.22, 0.8, 0.3, 1)';
    next.slide.style.transition = tr;
    old.slide.style.transition = tr;
    next.slide.style.transform = 'translateX(0)';
    old.slide.style.transform = 'translateX(' + -dir * hw + 'px)';
    setTimeout(() => {
      old.slide.remove();
      old.stage.clearHi();
      this.animating = false;
    }, 290);
  }

  next() {
    if (this.animating || this.index >= this.r.total - 1) return;
    this.show(this.index + 1, 1, true, 0);
  }

  prev() {
    if (this.animating || this.index <= 0) return;
    this.show(this.index - 1, -1, true, 0);
  }

  goTo(i) {
    const idx = clamp(i, 0, this.r.total - 1);
    if (idx === this.index) return;
    if (this.animating) {
      // finish instantly to keep state consistent
      this.host.querySelectorAll('.flat-slide').forEach((el) => {
        if (!this.cur || el !== this.cur.slide) el.remove();
      });
      this.animating = false;
    }
    const d = idx - this.index;
    this.show(idx, d > 0 ? 1 : -1, Math.abs(d) === 1, 0);
  }

  swipeMove(dx) {
    if (!this.cur || this.animating) return;
    this.cur.slide.style.transition = 'none';
    this.cur.slide.style.transform = 'translateX(' + dx + 'px)';
  }

  swipeEnd(dx, vx) {
    if (!this.cur || this.animating) return;
    const hw = this.host.clientWidth || 1;
    const commit = Math.abs(dx) > hw * 0.2 || (Math.abs(vx) > 0.45 && Math.abs(dx) > 24);
    const dir = dx < 0 ? 1 : -1;
    const target = this.index + dir;
    if (commit && target >= 0 && target < this.r.total) {
      this.show(target, dir, true, dx);
    } else {
      this.cur.slide.style.transition = 'transform 0.2s ease';
      this.cur.slide.style.transform = 'translateX(0)';
    }
  }

  onImage(i, url, w, hgt) {
    if (!this.cur || this.cur.index !== i) return;
    this.cur.stage.setUrl(url);
    const ratio = w / hgt;
    if (Math.abs(ratio - this.cur.stage.ratio) > 0.01) {
      this.cur.stage.ratio = ratio;
      this.relayout();
    }
  }

  onEvict() {}

  activeStage() {
    return this.cur ? this.cur.stage : null;
  }

  relayout() {
    if (!this.cur) return;
    this._layout(this.cur);
    this.r.gestures.setTarget(this.cur.stage.el, this.cur.stage.w, this.cur.stage.h);
  }

  destroy() {
    if (this.cur) this.cur.stage.clearHi();
    this.r.gestures.clearTarget();
    if (this.host) this.host.remove();
    this.cur = null;
  }
}

// ------------------------------------------------------------------ the reader
class PdfReader {
  constructor(file, mount, api) {
    this.file = file;
    this.mount = mount;
    this.api = api;
    this.destroyed = false;
    this.pdf = null;
    this.total = 0;
    this.ratio = 0.707;
    this.page = 0;
    this.mode = store.settings().curl ? 'curl' : 'flat';
    this.view = null;
    this.images = null;
    this.gestures = null;
    this.zoom = null;
    this.outline = null;
    this.saveTimer = null;
  }

  async start() {
    this.shell = createShell({ title: bookTitle(this.file.name), onBack: () => this.close() });
    this.mount.appendChild(this.shell.root);
    this._applyTheme(store.settings().pdfTheme);
    const s = store.settings();
    native.setImmersive(s.immersive);
    native.setKeepAwake(s.keepAwake);

    try {
      const res = await openPdfFile(this.file.path, { askPassword: (reason) => this.askPassword(reason) });
      if (this.destroyed) {
        try { res.pdf.destroy(); } catch (e) { /* ignore */ }
        return;
      }
      this.pdf = res.pdf;
    } catch (e) {
      if (this.destroyed) return;
      if (e && e.code === 'CANCELLED') {
        this.close();
        return;
      }
      this.shell.error(e && e.code === 'MISSING' ? t('reader.err.missing') : t('reader.err.open'));
      return;
    }

    this.total = this.pdf.numPages;
    try {
      this.ratio = clamp(await getPageRatio(this.pdf, 0), 0.25, 4);
    } catch (e) {
      this.ratio = 0.707;
    }
    if (this.destroyed) return;

    const hist = store.touchHistory(this.file);
    store.updateProgress(this.file.path, { total: this.total });
    this.page = clamp(hist.page || 0, 0, this.total - 1);

    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const shortSide = Math.min(window.screen.width || 360, window.screen.height || 640);
    const pixelWidth = clamp(Math.round(shortSide * dpr * 1.2), 700, 1800);
    this.images = new PageImages(this.pdf, {
      width: pixelWidth,
      onReady: (i, url, w, hh) => this._onImage(i, url, w, hh),
      onEvict: (i) => this.view && this.view.onEvict(i)
    });

    this._buildChrome();
    this.gestures = new Gestures(this.shell.stage, {
      swipe: this.mode === 'flat',
      onTap: (zone) => this._onTap(zone),
      onDoubleTap: (x, y) => this.openZoom(x, y),
      onSwipeMove: (dx) => this.view && this.view.swipeMove && this.view.swipeMove(dx),
      onSwipeEnd: (dx, vx) => this.view && this.view.swipeEnd && this.view.swipeEnd(dx, vx),
      onZoomSettle: (scale) => this._onZoomSettle(scale)
    });

    this._mountView();
    this.shell.ready();
    this.shell.schedule();

    this._onResize = debounce(() => this._handleResize(), 160);
    window.addEventListener('resize', this._onResize);
  }

  // ---------------------------------------------------------------- password
  askPassword(reason) {
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => {
        if (done) return;
        done = true;
        resolve(v);
      };
      const input = h('input', { class: 'field', type: 'password', placeholder: t('reader.password.placeholder'), autocomplete: 'off' });
      const dlg = dialog({
        title: t('reader.password.title'),
        message: reason === 2 ? t('reader.password.wrong') : '',
        body: input,
        dismissable: true,
        onClose: () => finish(null),
        actions: [
          { label: t('common.cancel'), kind: 'ghost' },
          { label: t('common.open'), kind: 'primary', onClick: () => finish(input.value) }
        ]
      });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          finish(input.value);
          dlg.close();
        }
      });
      setTimeout(() => input.focus(), 250);
    });
  }

  // ---------------------------------------------------------------- chrome
  _buildChrome() {
    const sh = this.shell;
    this.bookmarkBtn = iconBtn('bookmark', t('reader.bookmarks'), () => this.toggleBookmark(), 'sm');
    sh.setActions([
      iconBtn('search', t('reader.search'), () => this.openSearch(), 'sm'),
      this.bookmarkBtn,
      iconBtn('more', t('reader.more'), () => this.openMore(), 'sm')
    ]);

    this.slider = h('input', { class: 'range', type: 'range', min: '1', max: String(Math.max(1, this.total)), value: String(this.page + 1), step: '1' });
    this.label = h('div', { class: 'page-label' });
    this.slider.addEventListener('input', () => {
      this.label.textContent = num(this.slider.value) + ' / ' + num(this.total);
      sh.schedule();
    });
    this.slider.addEventListener('change', () => {
      this.goTo(Number(this.slider.value) - 1);
      sh.schedule();
    });

    this.btnCurl = h('button', { class: 'tool', type: 'button', onclick: () => this.setCurl(this.mode !== 'curl'), html: icon('curl', 22) });
    this.btnZoom = h('button', { class: 'tool', type: 'button', onclick: () => this.toggleZoom(), html: icon('zoomIn', 22) });
    this.btnTheme = h('button', { class: 'tool', type: 'button', onclick: () => this.cycleTheme() });
    const btnToc = h('button', { class: 'tool', type: 'button', onclick: () => this.openContents(), html: icon('list', 22) });
    [btnToc, this.btnCurl, this.btnZoom, this.btnTheme].forEach((b) => b.setAttribute('type', 'button'));
    btnToc.title = t('reader.contents');
    this.btnCurl.title = t('reader.curl');
    this.btnZoom.title = t('reader.zoom');

    sh.bottom.appendChild(h('div', { class: 'slider-row' }, this.slider, this.label));
    sh.bottom.appendChild(h('div', { class: 'tool-row' }, btnToc, this.btnCurl, this.btnZoom, this.btnTheme));
    this._refreshToolStates();
    this.refreshLabel();
  }

  _refreshToolStates() {
    this.btnCurl.classList.toggle('on', this.mode === 'curl');
    const th = store.settings().pdfTheme;
    this.btnTheme.innerHTML = icon(th === 'night' ? 'moon' : th === 'sepia' ? 'type' : 'sun', 22);
    this.btnTheme.title = t('reader.theme');
    this.btnZoom.classList.toggle('on', !!(this.zoom || (this.gestures && this.mode === 'flat' && this.gestures.zoomed)));
  }

  refreshLabel() {
    if (!this.label) return;
    const i = this.page;
    const spread = this.view && this.view.orientation() === 'landscape' && i + 1 < this.total;
    const first = num(i + 1);
    this.label.textContent = (spread ? first + '–' + num(i + 2) : first) + ' / ' + num(this.total);
    if (this.slider) {
      this.slider.value = String(i + 1);
      const pct = this.total > 1 ? (i / (this.total - 1)) * 100 : 100;
      this.slider.style.setProperty('--pct', pct + '%');
    }
  }

  _applyTheme(key) {
    this.shell.root.dataset.rtheme = THEMES.includes(key) ? key : 'day';
  }

  cycleTheme() {
    const cur = store.settings().pdfTheme;
    const next = THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length];
    store.setSetting('pdfTheme', next);
    this._applyTheme(next);
    this._refreshToolStates();
    toast(t('reader.' + next), 1200);
    this.shell.schedule();
  }

  // ---------------------------------------------------------------- view management
  _mountView() {
    if (this.view) {
      this.view.destroy();
      this.view = null;
    }
    this.closeZoom();
    this.gestures.o.swipe = this.mode === 'flat';
    this.view = this.mode === 'curl' ? new CurlView(this) : new FlatView(this);
    this.view.mount(this.page);
    this._refreshToolStates();
  }

  setCurl(on) {
    const want = on ? 'curl' : 'flat';
    if (want === this.mode) return;
    this.mode = want;
    store.setSetting('curl', on);
    this._mountView();
    toast(on ? t('reader.curlOn') : t('reader.curlOff'), 1300);
    this.shell.schedule();
  }

  _onImage(i, url, w, hh) {
    if (!this.view) return;
    this.view.onImage(i, url, w, hh);
    if (this.zoom && this.zoom.index === i) this.zoom.stage.setUrl(url);
  }

  setPage(i, from) {
    const idx = clamp(i, 0, Math.max(0, this.total - 1));
    const changed = idx !== this.page;
    this.page = idx;
    if (this.zoom && this.zoom.index !== idx && from !== 'zoom') this.closeZoom();
    this._prefetch(idx);
    this.refreshLabel();
    this._refreshBookmarkState();
    if (changed || from === 'init') this._queueSave();
  }

  _prefetch(i) {
    if (!this.images) return;
    const keep = this.mode === 'curl' ? 6 : 3;
    this.images.setCenter(i, keep);
    const order = [0, 1, -1, 2, 3, -2, 4, -3];
    for (const d of order) {
      if (Math.abs(d) > keep) continue;
      const idx = i + d;
      if (idx >= 0 && idx < this.total) this.images.request(idx);
    }
  }

  _queueSave() {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => this._saveNow(), 400);
  }

  _saveNow() {
    this.saveTimer = null;
    if (!this.total) return;
    store.updateProgress(this.file.path, {
      page: this.page,
      total: this.total,
      progress: this.total > 1 ? this.page / (this.total - 1) : 1,
      lastOpened: Date.now()
    });
  }

  goTo(i) {
    if (!this.view) return;
    this.view.goTo(clamp(i, 0, this.total - 1));
  }

  next() {
    if (this.view) this.view.next();
  }

  prev() {
    if (this.view) this.view.prev();
  }

  _onTap(zone) {
    if (zone === 'C') {
      this.shell.toggle();
      return;
    }
    if (zone === 'R') this.next();
    else this.prev();
    if (this.shell.root.dataset.chrome === 'on') this.shell.schedule();
  }

  _handleResize() {
    if (this.destroyed || !this.view) return;
    this.view.relayout();
    if (this.zoom) {
      this.closeZoom();
    }
    if (this.gestures) this.gestures.layout();
  }

  // ---------------------------------------------------------------- zoom
  toggleZoom() {
    const rect = this.shell.stage.getBoundingClientRect();
    if (this.mode === 'curl') {
      if (this.zoom) this.closeZoom();
      else this.openZoom(rect.width / 2, rect.height / 2, 2);
    } else if (this.gestures.zoomed) {
      this.gestures.reset(true);
    } else {
      this.gestures.zoomAt(2, rect.width / 2, rect.height / 2, true);
    }
    this.shell.schedule();
  }

  openZoom(x, y, scale) {
    if (this.mode !== 'curl' || this.zoom || !this.view) return;
    const stageEl = this.shell.stage;
    const rect = stageEl.getBoundingClientRect();
    let idx = this.page;
    if (this.view.orientation() === 'landscape' && x > rect.width / 2 && idx + 1 < this.total) idx += 1;
    const ps = new PageStage(idx);
    const cached = this.images.peek(idx);
    ps.fit(rect.width, rect.height, this.ratio);
    if (cached) ps.setUrl(cached);
    else this.images.request(idx);
    const layer = h('div', { class: 'zoom-layer' }, ps.el);
    stageEl.appendChild(layer);
    const entry = { close: () => this.closeZoom() };
    pushOverlay(entry);
    this.zoom = { layer, stage: ps, index: idx, entry };
    this.gestures.setTarget(ps.el, ps.w, ps.h);
    this.gestures.zoomAt(scale || 2.5, x, y, true);
    this._refreshToolStates();
    if (!store.getMeta('zoomHintShown', false)) {
      store.setMeta('zoomHintShown', true);
      toast(t('reader.zoomHint'), 3200);
    }
  }

  closeZoom() {
    if (!this.zoom) return;
    const z = this.zoom;
    this.zoom = null;
    popOverlay(z.entry);
    z.stage.clearHi();
    if (this.gestures) this.gestures.clearTarget();
    z.layer.remove();
    this._refreshToolStates();
  }

  _onZoomSettle(scale) {
    if (this.destroyed) return;
    const stage = this.zoom ? this.zoom.stage : this.view && this.view.activeStage ? this.view.activeStage() : null;
    if (scale <= 1.02) {
      if (stage) stage.clearHi();
      if (this.zoom) this.closeZoom();
    } else if (stage && scale > 1.25) {
      const dpr = Math.min(window.devicePixelRatio || 1, 3);
      stage.renderHi(this.pdf, clamp(Math.round(stage.w * scale * dpr), 600, 4096));
    }
    this._refreshToolStates();
  }

  // ---------------------------------------------------------------- bookmarks
  _bookmarkAt(page) {
    return store.getBookmarks(this.file.path).find((b) => b.page === page) || null;
  }

  _refreshBookmarkState() {
    if (!this.bookmarkBtn) return;
    const on = !!this._bookmarkAt(this.page);
    this.bookmarkBtn.classList.toggle('on', on);
    this.bookmarkBtn.innerHTML = icon('bookmark', 22, on);
  }

  toggleBookmark() {
    const existing = this._bookmarkAt(this.page);
    if (existing) {
      store.removeBookmark(this.file.path, existing.id);
      toast(t('reader.bookmarkRemoved'), 1200);
    } else {
      store.addBookmark(this.file.path, { page: this.page });
      toast(t('reader.bookmarkAdded'), 1200);
    }
    this._refreshBookmarkState();
    this.shell.schedule();
  }

  // ---------------------------------------------------------------- sheets
  async openContents() {
    const list = h('div', { class: 'list-body' });
    let tab = 'outline';
    let sh = null;
    const render = async () => {
      list.textContent = '';
      if (tab === 'outline') {
        if (!this.outline) this.outline = await getOutlineFlat(this.pdf);
        if (!this.outline.length) {
          list.appendChild(h('div', { class: 'empty-note' }, t('reader.noOutline')));
          return;
        }
        this.outline.forEach((it) => {
          list.appendChild(
            h(
              'button',
              {
                class: 'list-item',
                type: 'button',
                style: { paddingLeft: 14 + it.depth * 16 + 'px' },
                onclick: async () => {
                  const idx = await destToPageIndex(this.pdf, it.dest);
                  if (idx !== null) {
                    this.goTo(idx);
                    sh.close();
                  }
                }
              },
              h('span', { class: 'li-title' }, it.title)
            )
          );
        });
      } else {
        const marks = store.getBookmarks(this.file.path).slice().sort((a, b) => a.page - b.page);
        if (!marks.length) {
          list.appendChild(h('div', { class: 'empty-note' }, t('reader.noBookmarks')));
          return;
        }
        marks.forEach((m) => {
          list.appendChild(
            h(
              'div',
              { class: 'list-item split' },
              h('button', { class: 'li-main', type: 'button', onclick: () => { this.goTo(m.page); sh.close(); } },
                icon('bookmark', 18, true), h('span', { class: 'li-title' }, t('reader.page', { n: num(m.page + 1) }))),
              iconBtn('trash', t('common.close'), () => { store.removeBookmark(this.file.path, m.id); this._refreshBookmarkState(); render(); }, 'sm')
            )
          );
        });
      }
    };
    const tabs = segmented(
      [{ value: 'outline', label: t('reader.contents') }, { value: 'marks', label: t('reader.bookmarks') }],
      tab,
      (v) => { tab = v; render(); }
    );
    sh = sheet({ title: t('reader.contents'), body: h('div', null, tabs, list), tall: true });
    render();
  }

  openSearch() {
    const input = h('input', { class: 'field', type: 'search', placeholder: t('reader.searchPlaceholder'), enterkeyhint: 'search' });
    const prog = h('div', { class: 'muted' });
    const list = h('div', { class: 'list-body' });
    let token = 0;
    let sh = null;
    const run = async () => {
      const q = input.value.trim();
      const my = ++token;
      list.textContent = '';
      prog.textContent = '';
      if (!q) return;
      let any = false;
      await searchPdf(this.pdf, q, {
        isCancelled: () => my !== token || this.destroyed,
        onProgress: (p) => { if (my === token) prog.textContent = p < 1 ? t('reader.searching', { p: num(Math.round(p * 100)) }) : ''; },
        onResult: (res) => {
          if (my !== token) return;
          any = true;
          list.appendChild(
            h('button', { class: 'list-item col', type: 'button', onclick: () => { this.goTo(res.page); sh.close(); } },
              h('span', { class: 'li-title' }, t('reader.page', { n: num(res.page + 1) })),
              h('span', { class: 'li-sub' }, res.snippet))
          );
        }
      });
      if (my === token && !any) prog.textContent = t('reader.noResults');
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        input.blur();
        run();
      }
    });
    sh = sheet({ title: t('reader.search'), body: h('div', null, input, prog, list), tall: true, onClose: () => { token++; } });
    setTimeout(() => input.focus(), 320);
  }

  openMore() {
    const s = store.settings();
    const gotoInput = h('input', { class: 'field small', type: 'number', inputmode: 'numeric', min: '1', max: String(this.total), placeholder: num(this.page + 1) });
    let sh = null;
    const go = () => {
      const n = parseInt(gotoInput.value, 10);
      if (n >= 1 && n <= this.total) {
        this.goTo(n - 1);
        sh.close();
      }
    };
    gotoInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
    const body = h(
      'div',
      { class: 'rows' },
      row(t('reader.goto'), h('div', { class: 'inline' }, gotoInput, h('button', { class: 'btn primary sm', type: 'button', onclick: go }, t('common.open')))),
      row(t('reader.curl'), toggle(this.mode === 'curl', (v) => this.setCurl(v))),
      row(t('settings.speed'), segmented(
        [{ value: 'fast', label: t('settings.fast') }, { value: 'normal', label: t('settings.normal') }, { value: 'slow', label: t('settings.slow') }],
        s.speed,
        (v) => {
          store.setSetting('speed', v);
          if (this.mode === 'curl') this._mountView();
        })),
      row(t('reader.theme'), segmented(
        THEMES.map((k) => ({ value: k, label: t('reader.' + k) })),
        s.pdfTheme,
        (v) => { store.setSetting('pdfTheme', v); this._applyTheme(v); this._refreshToolStates(); })),
      h('div', { class: 'btn-row' },
        h('button', { class: 'btn ghost', type: 'button', onclick: () => this.share() }, t('action.share')),
        h('button', { class: 'btn ghost', type: 'button', onclick: () => this.showDetails() }, t('action.details')))
    );
    sh = sheet({ title: bookTitle(this.file.name), body });
  }

  async share() {
    try {
      await native.shareFile(this.file.path, bookTitle(this.file.name));
    } catch (e) {
      toast(t('toast.shareFailed'));
    }
  }

  showDetails() {
    const f = this.file;
    sheet({
      title: t('action.details'),
      body: h('div', { class: 'rows' },
        row(t('details.type'), h('span', { class: 'val' }, 'PDF')),
        row(t('details.pages'), h('span', { class: 'val' }, num(this.total))),
        row(t('details.size'), h('span', { class: 'val' }, fmtSize(f.size))),
        f.modified ? row(t('details.modified'), h('span', { class: 'val' }, fmtDate(f.modified))) : null,
        row(t('details.path'), h('span', { class: 'val path' }, f.path)))
    });
  }

  // ---------------------------------------------------------------- lifecycle
  close() {
    this.destroy();
    this.api.onClose();
  }

  handleBack() {
    this.close();
    return true;
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    if (this.saveTimer) clearTimeout(this.saveTimer);
    if (this.total && this.images) this._saveNow();
    if (this._onResize) window.removeEventListener('resize', this._onResize);
    this.closeZoom();
    if (this.view) this.view.destroy();
    if (this.gestures) this.gestures.destroy();
    if (this.images) this.images.destroy();
    if (this.pdf) {
      try { this.pdf.destroy(); } catch (e) { /* ignore */ }
    }
    this.shell.destroy();
    native.setImmersive(false);
    native.setKeepAwake(false);
  }
}

export function createPdfReader(file, mount, api) {
  return new PdfReader(file, mount, api);
}

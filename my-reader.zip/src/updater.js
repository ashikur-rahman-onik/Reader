// In-app update: checks the latest GitHub Release and installs its APK.
import cfg from './app-config.json';
import { h, dialog, toast } from './ui.js';
import { t, num } from './i18n.js';
import * as store from './store.js';
import { getAppInfo, downloadAndInstall } from './native.js';

const SIX_HOURS = 6 * 60 * 60 * 1000;
const TWELVE_HOURS = 12 * 60 * 60 * 1000;

export function updateRepo() {
  return String(store.settings().updateRepo || cfg.repo || '').trim();
}

export async function checkForUpdate() {
  const repo = updateRepo();
  if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) {
    const e = new Error('no source');
    e.code = 'NOSOURCE';
    throw e;
  }
  const info = await getAppInfo();
  const res = await fetch('https://api.github.com/repos/' + repo + '/releases/latest', {
    headers: { Accept: 'application/vnd.github+json' },
    cache: 'no-store'
  });
  if (!res.ok) {
    const e = new Error('HTTP ' + res.status);
    e.code = 'HTTP';
    throw e;
  }
  const rel = await res.json();
  const m = /build-(\d+)/.exec(String(rel.tag_name || ''));
  const code = m ? Number(m[1]) : 0;
  const asset = (rel.assets || []).find((a) => /\.apk$/i.test(a.name || ''));
  return {
    available: !!asset && code > info.versionCode,
    code,
    currentCode: info.versionCode,
    currentName: info.versionName,
    name: String(rel.name || rel.tag_name || ''),
    notes: String(rel.body || '').trim().slice(0, 700),
    url: asset ? asset.browser_download_url : '',
    size: asset ? asset.size : 0
  };
}

export function showUpdateDialog(info) {
  const fill = h('i');
  const bar = h('div', { class: 'progress', style: { display: 'none' } }, fill);
  const status = h('div', { class: 'dialog-msg small' });
  const body = h('div', { class: 'update-body' }, info.notes ? h('pre', { class: 'notes' }, info.notes) : null, bar, status);
  let busy = false;

  const setButtons = (disabled) => {
    dlg.box.querySelectorAll('.dialog-actions .btn').forEach((b) => {
      b.disabled = disabled;
    });
  };

  const start = async () => {
    if (busy) return;
    busy = true;
    setButtons(true);
    bar.style.display = 'block';
    fill.style.width = '0%';
    status.textContent = t('update.downloading', { p: num(0) + '%' });
    try {
      const r = await downloadAndInstall(info.url, (rec, total) => {
        const pct = total > 0 ? Math.min(100, Math.round((rec / total) * 100)) : 0;
        fill.style.width = pct + '%';
        status.textContent = t('update.downloading', { p: num(pct) + '%' });
      });
      if (r && r.needsPermission) {
        status.textContent = t('update.permission');
        bar.style.display = 'none';
        busy = false;
        setButtons(false);
        return;
      }
      status.textContent = t('update.installing');
      setTimeout(() => {
        busy = false;
        setButtons(false);
      }, 4000);
    } catch (e) {
      status.textContent = t('update.failed') + ': ' + (e && e.message ? e.message : '');
      bar.style.display = 'none';
      busy = false;
      setButtons(false);
    }
  };

  const dlg = dialog({
    title: t('update.available'),
    message: t('update.new', { v: info.name }),
    body,
    actions: [
      {
        label: t('update.later'),
        kind: 'ghost',
        onClick: () => store.setMeta('snooze_' + info.code, Date.now())
      },
      { label: t('update.now'), kind: 'primary', keepOpen: true, onClick: start }
    ]
  });
  return dlg;
}

// Silent check on startup (at most every six hours, and not again for 12h after "Later").
export async function autoCheck() {
  if (!store.settings().autoUpdate) return;
  if (Date.now() - store.getMeta('lastUpdateCheck', 0) < SIX_HOURS) return;
  store.setMeta('lastUpdateCheck', Date.now());
  try {
    const info = await checkForUpdate();
    if (!info.available) return;
    const snoozed = store.getMeta('snooze_' + info.code, 0);
    if (Date.now() - snoozed < TWELVE_HOURS) return;
    showUpdateDialog(info);
  } catch (e) {
    /* silent */
  }
}

// Manual check from Settings.
export async function manualCheck() {
  toast(t('update.checking'), 1500);
  try {
    const info = await checkForUpdate();
    if (info.available) showUpdateDialog(info);
    else toast(t('update.latest'));
  } catch (e) {
    if (e && e.code === 'NOSOURCE') toast(t('update.noSource'));
    else toast(t('update.failed'));
  }
}

import '@fontsource/plus-jakarta-sans/latin-500.css';
import '@fontsource/plus-jakarta-sans/latin-700.css';
import '@fontsource/plus-jakarta-sans/latin-800.css';
import './styles.css';
import { h, toast, closeTopOverlay } from './ui.js';
import { t, setLang } from './i18n.js';
import * as store from './store.js';
import * as native from './native.js';
import { applyTheme } from './theme.js';
import { Home } from './home.js';
import { openSettings } from './settings.js';
import { autoCheck } from './updater.js';

setLang(store.settings().lang);
applyTheme();

const root = document.getElementById('app');
const splash = h(
  'div',
  { class: 'splash' },
  h('div', { class: 'splash-card' }, h('img', { src: 'symbol.png', alt: '', class: 'splash-mark' })),
  h('div', { class: 'splash-name' }, 'My Reader')
);
document.body.appendChild(splash);

let home = null;
let reader = null;
let readerLayer = null;
let opening = false;
let access = true;
let lastBack = 0;

const app = {
  openSettings: () => openSettings(app),
  refreshHome: () => home && home.render(),
  async requestAccess() {
    try {
      await native.requestAccess();
    } catch (e) {
      /* settings screen could not be opened */
    }
  },
  async recheckAccess() {
    const ok = await native.hasAccess();
    const changed = ok !== access;
    access = ok;
    if (home) home.setAccess(ok);
    if (ok && (changed || !store.getLib().files.length) && home) home.startScan(false);
  },
  rebuild() {
    setLang(store.settings().lang);
    if (home) home.destroy();
    mountHome();
  },
  async openFile(file) {
    if (reader || opening) return;
    opening = true;
    try {
      let f = file;
      if (!f.size) {
        const st = await native.statFile(f.path);
        f = Object.assign({}, f, { size: st.size });
      }
      readerLayer = h('div', { class: 'reader-layer' });
      document.body.appendChild(readerLayer);
      home.setHidden(true);
      const mod = f.type === 'epub' ? await import('./epubreader.js') : await import('./pdfreader.js');
      const api = { onClose: () => closeReader() };
      reader = f.type === 'epub' ? mod.createEpubReader(f, readerLayer, api) : mod.createPdfReader(f, readerLayer, api);
      opening = false;
      await reader.start();
    } catch (e) {
      opening = false;
      closeReader();
      toast(t('reader.err.open'));
    }
  }
};

function closeReader() {
  if (reader) {
    try {
      reader.destroy();
    } catch (e) {
      /* ignore */
    }
  }
  reader = null;
  if (readerLayer) readerLayer.remove();
  readerLayer = null;
  if (home) home.setHidden(false);
  applyTheme();
}

function mountHome() {
  home = new Home(app);
  root.appendChild(home.el);
  home.setAccess(access);
  home.startScan(false);
}

async function openIncoming() {
  const r = await native.consumePendingOpen();
  if (!r) return;
  if (reader) {
    reader.destroy();
    closeReader();
  }
  app.openFile({ path: r.path, name: r.name || 'file', type: r.type === 'epub' ? 'epub' : 'pdf', size: 0, modified: 0 });
}

async function boot() {
  access = await native.hasAccess();
  mountHome();
  native.onResume(() => app.recheckAccess());
  native.onOpenIntent(() => openIncoming());
  native.onBackButton(() => {
    if (closeTopOverlay()) return;
    if (reader) {
      reader.handleBack();
      return;
    }
    if (home && home.handleBack()) return;
    const now = Date.now();
    if (now - lastBack < 1800) {
      native.exitApp();
    } else {
      lastBack = now;
      toast(t('toast.exitAgain'), 1600);
    }
  });
  setTimeout(() => {
    splash.classList.add('hide');
    setTimeout(() => splash.remove(), 500);
  }, 900);
  openIncoming();
  setTimeout(() => autoCheck(), 3000);
}

boot();

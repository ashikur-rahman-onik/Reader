// Shared reader chrome: full-screen stage, auto-hiding top/bottom bars, loading and error panels.
import { h, iconBtn, hasOverlay } from './ui.js';
import { icon } from './icons.js';
import { t } from './i18n.js';

export function createShell(opts) {
  const titleEl = h('div', { class: 'bar-title' }, opts.title || '');
  const actions = h('div', { class: 'bar-actions' });
  const top = h('header', { class: 'bar top glass' }, iconBtn('back', t('common.close'), () => opts.onBack(), 'sm'), titleEl, actions);
  const bottom = h('footer', { class: 'bar bottom glass' });
  const stage = h('div', { class: 'stage' });
  const loading = h('div', { class: 'reader-loading' }, h('div', { class: 'spinner' }), h('div', { class: 'reader-loading-text' }, t('reader.loading')));
  const root = h('section', { class: 'reader', 'data-chrome': 'on' }, stage, top, bottom, loading);
  let timer = null;

  const shell = {
    root, stage, top, bottom, titleEl, actions,
    keepChrome: false,
    show() {
      root.dataset.chrome = 'on';
      shell.schedule();
    },
    hide() {
      if (hasOverlay() || shell.keepChrome) return;
      root.dataset.chrome = 'off';
    },
    toggle() {
      if (root.dataset.chrome === 'on') {
        if (timer) clearTimeout(timer);
        shell.hide();
      } else {
        shell.show();
      }
    },
    schedule() {
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => shell.hide(), 4200);
    },
    setActions(nodes) {
      actions.textContent = '';
      nodes.forEach((n) => actions.appendChild(n));
    },
    ready() {
      loading.classList.add('gone');
      setTimeout(() => loading.remove(), 400);
    },
    error(message, onRetry) {
      loading.remove();
      const box = h(
        'div',
        { class: 'reader-error' },
        h('div', { class: 'reader-error-icon', html: icon('file', 40) }),
        h('p', null, message),
        h('button', { class: 'btn primary', type: 'button', onclick: () => opts.onBack() }, t('common.close')),
        onRetry ? h('button', { class: 'btn ghost', type: 'button', onclick: onRetry }, t('common.retry')) : null
      );
      stage.appendChild(box);
      root.dataset.chrome = 'on';
    },
    destroy() {
      if (timer) clearTimeout(timer);
      timer = null;
      root.remove();
    }
  };
  return shell;
}

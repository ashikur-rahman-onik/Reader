// EPUB helpers (epub.js is loaded lazily).
import { readWholeFile, statFile } from './native.js';

let libPromise = null;
export function loadEpubLib() {
  if (!libPromise) {
    libPromise = import('epubjs').then((m) => m.default || m);
    libPromise.catch(() => {
      libPromise = null;
    });
  }
  return libPromise;
}

export async function openEpubFile(path, onProgress) {
  const st = await statFile(path);
  if (!st.exists) {
    const e = new Error('missing');
    e.code = 'MISSING';
    throw e;
  }
  const [ePub, bytes] = await Promise.all([loadEpubLib(), readWholeFile(path, st.size, onProgress)]);
  const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  const book = ePub(buffer);
  await book.ready;
  return { book, size: st.size };
}

export async function renderEpubThumb(path, size) {
  if (size > 60 * 1024 * 1024) return null;
  const { book } = await openEpubFile(path);
  try {
    const coverUrl = await book.coverUrl();
    if (!coverUrl) return null;
    const blob = await (await fetch(coverUrl)).blob();
    const bmp = await createImageBitmap(blob);
    const w = 260;
    const h = Math.round((bmp.height / bmp.width) * w);
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = Math.min(h, 420);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bmp, 0, 0, w, h);
    return { url: canvas.toDataURL('image/jpeg', 0.8) };
  } finally {
    try {
      book.destroy();
    } catch (e) {
      /* ignore */
    }
  }
}

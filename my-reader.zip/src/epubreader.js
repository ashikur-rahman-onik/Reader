// EPUB reader (epub.js): paginated text with themes, font controls, contents, search and bookmarks.
import { h, iconBtn, sheet, toast, segmented, row, fmtSize, fmtDate, bookTitle, debounce, clamp } from './ui.js';
import { icon } from './icons.js';
import { t, num } from './i18n.js';
import * as store from './store.js';
import * as native from './native.js';
import { createShell } from './shell.js';
import { Gestures } from './gestures.js';
import { openEpubFile } from './epubsource.js';

const THEMES = ['day', 'sepia', 'night'];
const PALETTE = {
  day: { bg: '#ffffff', fg: '#1b1f2a' },
  sepia: { bg: '#f3ead3', fg: '#4a3b2a' },
  night: { bg: '#0f1530', fg: '#d5dbf0' }
};
const FAMILY = {
  serif: 'Georgia, "Noto Serif", "Noto Serif Bengali", serif',
  sans: '"Plus Jakarta Sans", "Noto Sans", "Noto Sans Bengali", system-ui, sans-serif'
};

class EpubReader {
  constructor(file, mount, api) {
    this.file = file;
    this.mount = mount;
    this.api = api;
    this.destroyed = false;
    this.book = null;
    this.rendition = null;
    this.toc = [];
    this.locReady = false;
    this.cfi = null;
    this.percent = 0;
    this.saveTimer = null;
  }

  async start() {
    this.shell = createShell({ title: bookTitle(this.file.name), onBack: () => this.close() });
    this.mount.appendChild(this.shell.root);
    const s = store.settings();
    native.setImmersive(s.immersive);
    native.setKeepAwake(s.keepAwake);

    try {
      const res = await openEpubFile(this.file.path);
      if (this.destroyed) {
        try { res.book.destroy(); } catch (e) { /* ignore */ }
        return;
      }
      this.book = res.book;
    } catch (e) {
      if (this.destroyed) return;
      this.shell.error(e && e.code === 'MISSING' ? t('reader.err.missing') : t('reader.err.open'));
      return;
    }

    try {
      const meta = await this.book.loaded.metadata;
      if (meta && meta.title) this.shell.titleEl.textContent = String(meta.title).trim();
    } catch (e) { /* ignore */ }
    try {
      const nav = await this.book.loaded.navigation;
      this.toc = nav && nav.toc ? nav.toc : [];
    } catch (e) {
      this.toc = [];
    }
    if (this.destroyed) return;

    const hist = store.touchHistory(this.file);
    this.wrap = h('div', { class: 'epub-wrap' });
    this.viewer = h('div', { class: 'epub-view' });
    this.wrap.appendChild(this.viewer);
    this.tapLayer = h('div', { class: 'epub-tap' });
    this.shell.stage.appendChild(this.wrap);
    this.shell.stage.appendChild(this.tapLayer);
    this._applyContainerStyle();

    this._buildChrome();

    this.gestures = new Gestures(this.tapLayer, {
      swipe: true,
      onTap: (zone) => this._onTap(zone),
      onSwipeEnd: (dx, vx) => {
        if (Math.abs(dx) > 40 || Math.abs(vx) > 0.4) {
          if (dx < 0) this.next();
          else this.prev();
        }
      }
    });

    this.rendition = this.book.renderTo(this.viewer, {
      width: '100%',
      height: '100%',
      flow: 'paginated',
      spread: 'none',
      allowScriptedContent: false
    });
    Object.keys(PALETTE).forEach((k) => {
      const p = PALETTE[k];
      this.rendition.themes.register(k, {
        'html, body': { background: p.bg + ' !important' },
        'body, p, div, span, li, h1, h2, h3, h4, h5, h6, blockquote, td, th, em, strong, i, b': { color: p.fg + ' !important' }
      });
    });
    this._applyTextStyle();
    this.rendition.on('relocated', (loc) => this._onRelocated(loc));

    try {
      await this.rendition.display(hist.cfi || undefined);
    } catch (e) {
      try { await this.rendition.display(); } catch (e2) { /* ignore */ }
    }
    if (this.destroyed) return;
    this.shell.ready();
    this.shell.schedule();

    this.book.ready
      .then(() => this.book.locations.generate(1200))
      .then(() => {
        if (this.destroyed) return;
        this.locReady = true;
        this.slider.disabled = false;
        if (this.cfi) this.percent = this.book.locations.percentageFromCfi(this.cfi) || this.percent;
        this.refreshLabel();
      })
      .catch(() => {});
  }

  // ---------------------------------------------------------------- styling
  _applyContainerStyle() {
    const m = store.settings().epubMargin;
    this.wrap.dataset.margin = String(m);
    const p = PALETTE[store.settings().epubTheme] || PALETTE.day;
    this.shell.root.dataset.rtheme = store.settings().epubTheme;
    this.shell.stage.style.background = p.bg;
    this.wrap.style.background = p.bg;
  }

  _applyTextStyle() {
    if (!this.rendition) return;
    const s = store.settings();
    const th = this.rendition.themes;
    th.select(THEMES.includes(s.epubTheme) ? s.epubTheme : 'day');
    th.fontSize(clamp(s.epubFont, 60, 260) + '%');
    th.override('line-height', String(s.epubLine), true);
    th.override('font-family', FAMILY[s.epubFamily] || '', s.epubFamily !== 'original');
  }

  _relayout() {
    if (!this.rendition) return;
    setTimeout(() => {
      try {
        this.rendition.resize();
      } catch (e) { /* ignore */ }
    }, 30);
  }

  // ---------------------------------------------------------------- chrome
  _buildChrome() {
    const sh = this.shell;
    this.bookmarkBtn = iconBtn('bookmark', t('reader.bookmarks'), () => this.toggleBookmark(), 'sm');
    sh.setActions([
      iconBtn('search', t('reader.search'), () => this.openSearch(), 'sm'),
      this.bookmarkBtn,
      iconBtn('more', t('reader.more'), () => this.openMore(), 'sm')
    ]);
    this.slider = h('input', { class: 'range', type: 'range', min: '0', max: '1000', value: '0', step: '1', disabled: true });
    this.label = h('div', { class: 'page-label' });
    this.slider.addEventListener('input', () => {
      this.label.textContent = num(Math.round(Number(this.slider.value) / 10)) + '%';
      sh.schedule();
    });
    this.slider.addEventListener('change', () => {
      if (!this.locReady) return;
      try {
        const cfi = this.book.locations.cfiFromPercentage(clamp(Number(this.slider.value) / 1000, 0, 0.999));
        if (cfi) this.rendition.display(cfi);
      } catch (e) { /* ignore */ }
      sh.schedule();
    });
    const btnToc = h('button', { class: 'tool', type: 'button', title: t('reader.contents'), onclick: () => this.openContents(), html: icon('list', 22) });
    const btnTheme = h('button', { class: 'tool', type: 'button', title: t('reader.theme'), onclick: () => this.cycleTheme() });
    const btnText = h('button', { class: 'tool', type: 'button', title: t('epub.font'), onclick: () => this.openTextSettings(), html: icon('type', 22) });
    this.btnTheme = btnTheme;
    sh.bottom.appendChild(h('div', { class: 'slider-row' }, this.slider, this.label));
    sh.bottom.appendChild(h('div', { class: 'tool-row' }, btnToc, btnText, btnTheme));
    this._refreshTheme();
    this.refreshLabel();
  }

  _refreshTheme() {
    const th = store.settings().epubTheme;
    this.btnTheme.innerHTML = icon(th === 'night' ? 'moon' : th === 'sepia' ? 'type' : 'sun', 22);
  }

  refreshLabel() {
    if (!this.label) return;
    const pct = Math.round(this.percent * 100);
    this.label.textContent = this.locReady || pct > 0 ? num(pct) + '%' : t('epub.preparing');
    if (this.slider) {
      this.slider.value = String(Math.round(this.percent * 1000));
      this.slider.style.setProperty('--pct', this.percent * 100 + '%');
    }
  }

  cycleTheme() {
    const cur = store.settings().epubTheme;
    const next = THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length];
    store.setSetting('epubTheme', next);
    this._applyContainerStyle();
    this._applyTextStyle();
    this._refreshTheme();
    toast(t('reader.' + next), 1200);
    this.shell.schedule();
  }

  // ---------------------------------------------------------------- navigation
  _onRelocated(loc) {
    if (this.destroyed || !loc || !loc.start) return;
    this.cfi = loc.start.cfi;
    let p = 0;
    if (this.locReady) p = this.book.locations.percentageFromCfi(this.cfi);
    else if (typeof loc.start.percentage === 'number') p = loc.start.percentage;
    this.percent = clamp(p || 0, 0, 1);
    if (loc.atEnd) this.percent = 1;
    this.refreshLabel();
    this._refreshBookmarkState();
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => this._saveNow(), 500);
  }

  _saveNow() {
    this.saveTimer = null;
    if (!this.cfi) return;
    store.updateProgress(this.file.path, { cfi: this.cfi, progress: this.percent, lastOpened: Date.now() });
  }

  _animate(dir) {
    const el = this.viewer;
    el.classList.remove('turn-next', 'turn-prev');
    void el.offsetWidth;
    el.classList.add(dir > 0 ? 'turn-next' : 'turn-prev');
  }

  next() {
    if (!this.rendition) return;
    this._animate(1);
    this.rendition.next();
  }

  prev() {
    if (!this.rendition) return;
    this._animate(-1);
    this.rendition.prev();
  }

  _onTap(zone) {
    if (zone === 'C') {
      this.shell.toggle();
      return;
    }
    if (zone === 'R') this.next();
    else this.prev();
    if (this.shell.root.dataset.chrome === 'on') this.shell.schedule();
  }

  // ---------------------------------------------------------------- bookmarks
  _refreshBookmarkState() {
    if (!this.bookmarkBtn) return;
    const on = store.getBookmarks(this.file.path).some((b) => b.cfi === this.cfi);
    this.bookmarkBtn.classList.toggle('on', on);
    this.bookmarkBtn.innerHTML = icon('bookmark', 22, on);
  }

  toggleBookmark() {
    if (!this.cfi) return;
    const existing = store.getBookmarks(this.file.path).find((b) => b.cfi === this.cfi);
    if (existing) {
      store.removeBookmark(this.file.path, existing.id);
      toast(t('reader.bookmarkRemoved'), 1200);
    } else {
      store.addBookmark(this.file.path, { cfi: this.cfi, percent: this.percent });
      toast(t('reader.bookmarkAdded'), 1200);
    }
    this._refreshBookmarkState();
    this.shell.schedule();
  }

  // ---------------------------------------------------------------- sheets
  openContents() {
    const list = h('div', { class: 'list-body' });
    let tab = 'outline';
    let sh = null;
    const flat = [];
    const walk = (items, depth) => (items || []).forEach((it) => {
      flat.push({ label: String(it.label || '').trim() || '—', href: it.href, depth });
      if (it.subitems && it.subitems.length && depth < 4) walk(it.subitems, depth + 1);
    });
    walk(this.toc, 0);
    const render = () => {
      list.textContent = '';
      if (tab === 'outline') {
        if (!flat.length) {
          list.appendChild(h('div', { class: 'empty-note' }, t('reader.noOutline')));
          return;
        }
        flat.forEach((it) => list.appendChild(
          h('button', {
            class: 'list-item', type: 'button', style: { paddingLeft: 14 + it.depth * 16 + 'px' },
            onclick: () => { this.rendition.display(it.href); sh.close(); }
          }, h('span', { class: 'li-title' }, it.label))
        ));
      } else {
        const marks = store.getBookmarks(this.file.path).slice().sort((a, b) => (a.percent || 0) - (b.percent || 0));
        if (!marks.length) {
          list.appendChild(h('div', { class: 'empty-note' }, t('reader.noBookmarks')));
          return;
        }
        marks.forEach((m) => list.appendChild(
          h('div', { class: 'list-item split' },
            h('button', { class: 'li-main', type: 'button', onclick: () => { this.rendition.display(m.cfi); sh.close(); } },
              icon('bookmark', 18, true), h('span', { class: 'li-title' }, num(Math.round((m.percent || 0) * 100)) + '%')),
            iconBtn('trash', t('common.close'), () => { store.removeBookmark(this.file.path, m.id); this._refreshBookmarkState(); render(); }, 'sm'))
        ));
      }
    };
    const tabs = segmented(
      [{ value: 'outline', label: t('reader.contents') }, { value: 'marks', label: t('reader.bookmarks') }],
      tab,
      (v) => { tab = v; render(); }
    );
    sh = sheet({ title: t('reader.contents'), body: h('div', null, tabs, list), tall: true });
    render();
  }

  openSearch() {
    const input = h('input', { class: 'field', type: 'search', placeholder: t('reader.searchPlaceholder'), enterkeyhint: 'search' });
    const prog = h('div', { class: 'muted' });
    const list = h('div', { class: 'list-body' });
    let token = 0;
    let sh = null;
    const run = async () => {
      const q = input.value.trim();
      const my = ++token;
      list.textContent = '';
      prog.textContent = '';
      if (!q) return;
      let any = false;
      let count = 0;
      const items = this.book.spine.spineItems || [];
      for (let i = 0; i < items.length; i++) {
        if (my !== token || this.destroyed) return;
        const item = items[i];
        try {
          await item.load(this.book.load.bind(this.book));
          const found = item.find(q) || [];
          found.slice(0, 5).forEach((r) => {
            any = true;
            count++;
            list.appendChild(
              h('button', { class: 'list-item col', type: 'button', onclick: () => { this.rendition.display(r.cfi); sh.close(); } },
                h('span', { class: 'li-sub' }, String(r.excerpt || '').trim()))
            );
          });
        } catch (e) { /* skip section */ }
        try { item.unload(); } catch (e) { /* ignore */ }
        prog.textContent = t('reader.searching', { p: num(Math.round(((i + 1) / items.length) * 100)) });
        if (count >= 200) break;
      }
      if (my === token) prog.textContent = any ? '' : t('reader.noResults');
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        input.blur();
        run();
      }
    });
    sh = sheet({ title: t('reader.search'), body: h('div', null, input, prog, list), tall: true, onClose: () => { token++; } });
    setTimeout(() => input.focus(), 320);
  }

  openTextSettings() {
    const s = store.settings();
    const sizeLabel = h('span', { class: 'val' }, num(s.epubFont) + '%');
    const setSize = (v) => {
      const nv = clamp(v, 70, 240);
      store.setSetting('epubFont', nv);
      sizeLabel.textContent = num(nv) + '%';
      this._applyTextStyle();
      this._relayout();
    };
    const stepper = h('div', { class: 'stepper' },
      h('button', { class: 'btn ghost sm', type: 'button', onclick: () => setSize(store.settings().epubFont - 10), html: icon('minus', 18) }),
      sizeLabel,
      h('button', { class: 'btn ghost sm', type: 'button', onclick: () => setSize(store.settings().epubFont + 10), html: icon('plus', 18) }));
    const body = h('div', { class: 'rows' },
      row(t('epub.font'), stepper),
      row(t('epub.family'), segmented(
        [{ value: 'serif', label: t('epub.serif') }, { value: 'sans', label: t('epub.sans') }, { value: 'original', label: t('epub.original') }],
        s.epubFamily, (v) => { store.setSetting('epubFamily', v); this._applyTextStyle(); this._relayout(); })),
      row(t('epub.line'), segmented(
        [{ value: 1.35, label: '1.35' }, { value: 1.6, label: '1.6' }, { value: 1.9, label: '1.9' }],
        s.epubLine, (v) => { store.setSetting('epubLine', v); this._applyTextStyle(); this._relayout(); })),
      row(t('epub.margin'), segmented(
        [{ value: 0, label: '–' }, { value: 1, label: '•' }, { value: 2, label: '••' }],
        s.epubMargin, (v) => { store.setSetting('epubMargin', v); this._applyContainerStyle(); this._relayout(); })),
      row(t('reader.theme'), segmented(
        THEMES.map((k) => ({ value: k, label: t('reader.' + k) })),
        s.epubTheme, (v) => { store.setSetting('epubTheme', v); this._applyContainerStyle(); this._applyTextStyle(); this._refreshTheme(); }))
    );
    sheet({ title: t('epub.font'), body });
  }

  openMore() {
    const body = h('div', { class: 'rows' },
      h('div', { class: 'btn-row' },
        h('button', { class: 'btn ghost', type: 'button', onclick: () => this.share() }, t('action.share')),
        h('button', { class: 'btn ghost', type: 'button', onclick: () => this.showDetails() }, t('action.details')),
        h('button', { class: 'btn ghost', type: 'button', onclick: () => this.openTextSettings() }, t('epub.font'))));
    sheet({ title: this.shell.titleEl.textContent, body });
  }

  async share() {
    try {
      await native.shareFile(this.file.path, bookTitle(this.file.name));
    } catch (e) {
      toast(t('toast.shareFailed'));
    }
  }

  showDetails() {
    const f = this.file;
    sheet({
      title: t('action.details'),
      body: h('div', { class: 'rows' },
        row(t('details.type'), h('span', { class: 'val' }, 'EPUB')),
        row(t('details.size'), h('span', { class: 'val' }, fmtSize(f.size))),
        f.modified ? row(t('details.modified'), h('span', { class: 'val' }, fmtDate(f.modified))) : null,
        row(t('details.path'), h('span', { class: 'val path' }, f.path)))
    });
  }

  // ---------------------------------------------------------------- lifecycle
  close() {
    this.destroy();
    this.api.onClose();
  }

  handleBack() {
    this.close();
    return true;
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this._saveNow();
    if (this.gestures) this.gestures.destroy();
    try { if (this.rendition) this.rendition.destroy(); } catch (e) { /* ignore */ }
    try { if (this.book) this.book.destroy(); } catch (e) { /* ignore */ }
    this.shell.destroy();
    native.setImmersive(false);
    native.setKeepAwake(false);
  }
}

export function createEpubReader(file, mount, api) {
  return new EpubReader(file, mount, api);
}

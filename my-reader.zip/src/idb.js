// Minimal IndexedDB key-value store for thumbnails.
let dbPromise = null;

function open() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    try {
      const req = indexedDB.open('myreader', 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore('thumbs');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch (e) {
      resolve(null);
    }
  });
  return dbPromise;
}

export async function idbGet(key) {
  const db = await open();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const r = db.transaction('thumbs', 'readonly').objectStore('thumbs').get(key);
      r.onsuccess = () => resolve(r.result === undefined ? null : r.result);
      r.onerror = () => resolve(null);
    } catch (e) {
      resolve(null);
    }
  });
}

export async function idbPut(key, value) {
  const db = await open();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction('thumbs', 'readwrite');
      tx.objectStore('thumbs').put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
      tx.onabort = () => resolve();
    } catch (e) {
      resolve();
    }
  });
}

export async function idbClear() {
  const db = await open();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction('thumbs', 'readwrite');
      tx.objectStore('thumbs').clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
      tx.onabort = () => resolve();
    } catch (e) {
      resolve();
    }
  });
}

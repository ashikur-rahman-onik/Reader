// Small DOM helpers: element builder, toast, bottom sheet, dialog, overlay stack, formatters.
import { icon } from './icons.js';
import { t, getLang } from './i18n.js';

export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props) {
    for (const k of Object.keys(props)) {
      const v = props[k];
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'html') el.innerHTML = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  const add = (kid) => {
    if (kid === null || kid === undefined || kid === false) return;
    if (Array.isArray(kid)) kid.forEach(add);
    else if (kid instanceof Node) el.appendChild(kid);
    else el.appendChild(document.createTextNode(String(kid)));
  };
  kids.forEach(add);
  return el;
}

export function iconBtn(name, label, onClick, cls) {
  return h('button', { class: 'icon-btn ' + (cls || ''), type: 'button', 'aria-label': label, title: label, onclick: onClick, html: icon(name, 22) });
}

// ---------------------------------------------------------------- overlay stack (for Android back button)
const stack = [];
export function pushOverlay(o) {
  stack.push(o);
}
export function popOverlay(o) {
  const i = stack.indexOf(o);
  if (i >= 0) stack.splice(i, 1);
}
export function closeTopOverlay() {
  const o = stack[stack.length - 1];
  if (!o) return false;
  o.close();
  return true;
}
export function hasOverlay() {
  return stack.length > 0;
}

// ---------------------------------------------------------------- toast
let toastEl = null;
let toastTimer = null;
export function toast(msg, ms) {
  if (!toastEl) {
    toastEl = h('div', { class: 'toast', role: 'status' });
    document.body.appendChild(toastEl);
  }
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl && toastEl.classList.remove('show'), ms || 2200);
}

// ---------------------------------------------------------------- bottom sheet
export function sheet(opts) {
  const o = opts || {};
  let closed = false;
  const body = h('div', { class: 'sheet-body' });
  if (o.body) body.appendChild(o.body);
  const head = o.title
    ? h('div', { class: 'sheet-head' }, h('h2', null, o.title), iconBtn('x', t('common.close'), () => api.close(), 'sm'))
    : null;
  const panel = h('div', { class: 'sheet-panel glass' + (o.tall ? ' tall' : '') }, h('div', { class: 'sheet-grip' }), head, body);
  const backdrop = h('div', { class: 'sheet-backdrop', onclick: () => api.close() });
  const root = h('div', { class: 'sheet-root' + (o.cls ? ' ' + o.cls : '') }, backdrop, panel);
  const api = {
    el: root,
    body,
    close() {
      if (closed) return;
      closed = true;
      popOverlay(api);
      root.classList.remove('open');
      setTimeout(() => root.remove(), 260);
      if (o.onClose) o.onClose();
    }
  };
  document.body.appendChild(root);
  pushOverlay(api);
  requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('open')));
  return api;
}

// ---------------------------------------------------------------- dialog
export function dialog(opts) {
  const o = opts || {};
  let closed = false;
  const actions = (o.actions || []).map((a) =>
    h(
      'button',
      {
        type: 'button',
        class: 'btn ' + (a.kind || 'ghost'),
        onclick: () => {
          if (!a.keepOpen) api.close();
          if (a.onClick) a.onClick(api);
        }
      },
      a.label
    )
  );
  const box = h(
    'div',
    { class: 'dialog-box glass', role: 'dialog', 'aria-modal': 'true' },
    o.title ? h('h2', null, o.title) : null,
    o.message ? h('p', { class: 'dialog-msg' }, o.message) : null,
    o.body || null,
    actions.length ? h('div', { class: 'dialog-actions' }, actions) : null
  );
  const root = h('div', { class: 'dialog-root' }, h('div', { class: 'sheet-backdrop', onclick: () => o.dismissable !== false && api.close() }), box);
  const api = {
    el: root,
    box,
    close() {
      if (closed) return;
      closed = true;
      popOverlay(api);
      root.classList.remove('open');
      setTimeout(() => root.remove(), 220);
      if (o.onClose) o.onClose();
    }
  };
  document.body.appendChild(root);
  pushOverlay(api);
  requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('open')));
  return api;
}

// ---------------------------------------------------------------- controls
export function toggle(checked, onChange) {
  const input = h('input', { type: 'checkbox', class: 'switch-input' });
  input.checked = !!checked;
  input.addEventListener('change', () => onChange(input.checked));
  return h('label', { class: 'switch' }, input, h('span', { class: 'switch-track' }, h('span', { class: 'switch-thumb' })));
}

export function segmented(options, value, onChange) {
  const wrap = h('div', { class: 'segmented', role: 'group' });
  const btns = options.map((opt) => {
    const b = h(
      'button',
      {
        type: 'button',
        class: 'seg' + (opt.value === value ? ' on' : ''),
        onclick: () => {
          btns.forEach((x) => x.classList.remove('on'));
          b.classList.add('on');
          onChange(opt.value);
        }
      },
      opt.label
    );
    return b;
  });
  btns.forEach((b) => wrap.appendChild(b));
  return wrap;
}

export function row(label, control, hint) {
  return h('div', { class: 'row' }, h('div', { class: 'row-text' }, h('div', { class: 'row-label' }, label), hint ? h('div', { class: 'row-hint' }, hint) : null), control || null);
}

// ---------------------------------------------------------------- formatters
export function fmtSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(0) + ' KB';
  if (n < 1024 * 1024 * 1024) return (n / (1024 * 1024)).toFixed(n < 10 * 1024 * 1024 ? 1 : 0) + ' MB';
  return (n / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}

export function fmtDate(ts) {
  if (!ts) return '';
  try {
    return new Intl.DateTimeFormat(getLang() === 'bn' ? 'bn-BD' : 'en-GB', { year: 'numeric', month: 'short', day: 'numeric' }).format(new Date(ts));
  } catch (e) {
    return new Date(ts).toDateString();
  }
}

export function bookTitle(name) {
  return String(name || '')
    .replace(/\.(pdf|epub)$/i, '')
    .replace(/[_]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

export function dirName(path) {
  const parts = String(path || '').split('/');
  parts.pop();
  return parts[parts.length - 1] || '';
}

export function debounce(fn, ms) {
  let tm = null;
  return (...a) => {
    if (tm) clearTimeout(tm);
    tm = setTimeout(() => fn(...a), ms);
  };
}

export function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, v));
}

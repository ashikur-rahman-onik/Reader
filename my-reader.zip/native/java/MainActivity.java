package com.sctc.reader;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MyReaderPlugin.class);
        super.onCreate(savedInstanceState);
    }
}

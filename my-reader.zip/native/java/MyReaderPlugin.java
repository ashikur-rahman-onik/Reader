package com.sctc.reader;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;

@CapacitorPlugin(name = "MyReaderNative")
public class MyReaderPlugin extends Plugin {

    private Uri pendingUri = null;

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void load() {
        handleIntent(getActivity() != null ? getActivity().getIntent() : null);
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        if (handleIntent(intent)) {
            notifyListeners("openIntent", new JSObject());
        }
    }

    private boolean handleIntent(Intent intent) {
        if (intent == null) return false;
        if (!Intent.ACTION_VIEW.equals(intent.getAction())) return false;
        Uri uri = intent.getData();
        if (uri == null) return false;
        pendingUri = uri;
        // mark as consumed so a re-delivery of the same intent is ignored
        intent.setAction(Intent.ACTION_MAIN);
        intent.setData(null);
        return true;
    }

    // ---------------------------------------------------------------- storage permission

    private boolean hasAccessInternal() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void hasAccess(PluginCall call) {
        JSObject o = new JSObject();
        o.put("granted", hasAccessInternal());
        call.resolve(o);
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + getContext().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                } catch (Exception e) {
                    Intent i = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                }
            } else {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 7001);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    // ---------------------------------------------------------------- scanning

    @PluginMethod
    public void scanFiles(final PluginCall call) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSArray out = new JSArray();
                    File root = Environment.getExternalStorageDirectory();
                    ArrayDeque<File> stack = new ArrayDeque<File>();
                    stack.push(root);
                    int found = 0;
                    int visited = 0;
                    while (!stack.isEmpty() && visited < 60000 && found < 20000) {
                        File dir = stack.pop();
                        visited++;
                        File[] list = dir.listFiles();
                        if (list == null) continue;
                        for (File f : list) {
                            String name = f.getName();
                            if (f.isDirectory()) {
                                if (name.startsWith(".")) continue;
                                if (dir.equals(root) && name.equals("Android")) continue;
                                stack.push(f);
                            } else {
                                String lower = name.toLowerCase(Locale.ROOT);
                                boolean pdf = lower.endsWith(".pdf");
                                boolean epub = lower.endsWith(".epub");
                                if (!pdf && !epub) continue;
                                long len = f.length();
                                if (len <= 0) continue;
                                JSObject o = new JSObject();
                                o.put("path", f.getAbsolutePath());
                                o.put("name", name);
                                o.put("size", len);
                                o.put("modified", f.lastModified());
                                o.put("type", pdf ? "pdf" : "epub");
                                out.put(o);
                                found++;
                            }
                        }
                    }
                    JSObject res = new JSObject();
                    res.put("files", out);
                    call.resolve(res);
                } catch (Throwable t) {
                    call.reject(String.valueOf(t.getMessage()));
                }
            }
        }).start();
    }

    @PluginMethod
    public void statFile(PluginCall call) {
        String path = call.getString("path");
        JSObject o = new JSObject();
        if (path == null) {
            o.put("exists", false);
        } else {
            File f = new File(path);
            o.put("exists", f.isFile());
            o.put("size", f.length());
        }
        call.resolve(o);
    }

    @PluginMethod
    public void readChunk(PluginCall call) {
        String path = call.getString("path");
        Double offD = call.getDouble("offset", 0.0);
        Double lenD = call.getDouble("length", 65536.0);
        if (path == null) {
            call.reject("path missing");
            return;
        }
        RandomAccessFile raf = null;
        try {
            long offset = (long) offD.doubleValue();
            int length = (int) lenD.doubleValue();
            if (length < 0) length = 0;
            if (length > 4 * 1024 * 1024) length = 4 * 1024 * 1024;
            raf = new RandomAccessFile(new File(path), "r");
            long size = raf.length();
            if (offset >= size) {
                JSObject o = new JSObject();
                o.put("data", "");
                o.put("size", size);
                call.resolve(o);
                return;
            }
            if (offset + length > size) length = (int) (size - offset);
            byte[] buf = new byte[length];
            raf.seek(offset);
            int total = 0;
            while (total < length) {
                int n = raf.read(buf, total, length - total);
                if (n < 0) break;
                total += n;
            }
            JSObject o = new JSObject();
            o.put("data", Base64.encodeToString(buf, 0, total, Base64.NO_WRAP));
            o.put("size", size);
            call.resolve(o);
        } catch (Throwable t) {
            call.reject(String.valueOf(t.getMessage()));
        } finally {
            if (raf != null) {
                try { raf.close(); } catch (Exception ignored) { }
            }
        }
    }

    // ---------------------------------------------------------------- "Open with" intent

    @PluginMethod
    public void consumePendingOpen(final PluginCall call) {
        final Uri uri = pendingUri;
        pendingUri = null;
        if (uri == null) {
            call.resolve(new JSObject());
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String scheme = uri.getScheme();
                    JSObject res = new JSObject();
                    if ("file".equals(scheme) && uri.getPath() != null) {
                        File f = new File(uri.getPath());
                        res.put("path", f.getAbsolutePath());
                        res.put("name", f.getName());
                        res.put("type", f.getName().toLowerCase(Locale.ROOT).endsWith(".epub") ? "epub" : "pdf");
                        call.resolve(res);
                        return;
                    }
                    Context ctx = getContext();
                    String name = queryName(uri);
                    String mime = ctx.getContentResolver().getType(uri);
                    boolean epub = (mime != null && mime.contains("epub"))
                            || (name != null && name.toLowerCase(Locale.ROOT).endsWith(".epub"));
                    if (name == null || name.length() == 0) {
                        name = epub ? "book.epub" : "document.pdf";
                    }
                    String lower = name.toLowerCase(Locale.ROOT);
                    if (!lower.endsWith(".pdf") && !lower.endsWith(".epub")) {
                        name = name + (epub ? ".epub" : ".pdf");
                    }
                    String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                    File dir = new File(ctx.getCacheDir(), "opened");
                    if (!dir.exists()) dir.mkdirs();
                    File target = new File(dir, System.currentTimeMillis() + "_" + safe);
                    InputStream in = ctx.getContentResolver().openInputStream(uri);
                    if (in == null) {
                        call.reject("Cannot open file");
                        return;
                    }
                    OutputStream outS = new FileOutputStream(target);
                    try {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            outS.write(buf, 0, n);
                        }
                    } finally {
                        try { outS.close(); } catch (Exception ignored) { }
                        try { in.close(); } catch (Exception ignored) { }
                    }
                    trimOpenedCache(dir, 6);
                    res.put("path", target.getAbsolutePath());
                    res.put("name", name);
                    res.put("type", epub || target.getName().toLowerCase(Locale.ROOT).endsWith(".epub") ? "epub" : "pdf");
                    call.resolve(res);
                } catch (Throwable t) {
                    call.reject(String.valueOf(t.getMessage()));
                }
            }
        }).start();
    }

    private String queryName(Uri uri) {
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        String last = uri.getLastPathSegment();
        return last;
    }

    private void trimOpenedCache(File dir, int keep) {
        File[] files = dir.listFiles();
        if (files == null || files.length <= keep) return;
        Arrays.sort(files, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        for (int i = keep; i < files.length; i++) {
            files[i].delete();
        }
    }

    // ---------------------------------------------------------------- window / system bars

    @PluginMethod
    public void setBars(final PluginCall call) {
        final String color = call.getString("color", "#070d24");
        final boolean light = Boolean.TRUE.equals(call.getBoolean("light", false));
        final Activity act = getActivity();
        if (act == null) {
            call.resolve();
            return;
        }
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    int c = Color.parseColor(color);
                    Window w = act.getWindow();
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    WindowInsetsControllerCompat ctl = WindowCompat.getInsetsController(w, w.getDecorView());
                    ctl.setAppearanceLightStatusBars(light);
                    ctl.setAppearanceLightNavigationBars(light);
                } catch (Exception ignored) {
                }
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void setImmersive(final PluginCall call) {
        final boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        final Activity act = getActivity();
        if (act == null) {
            call.resolve();
            return;
        }
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = act.getWindow();
                    WindowInsetsControllerCompat ctl = WindowCompat.getInsetsController(w, w.getDecorView());
                    if (enabled) {
                        ctl.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        ctl.hide(WindowInsetsCompat.Type.systemBars());
                    } else {
                        ctl.show(WindowInsetsCompat.Type.systemBars());
                    }
                } catch (Exception ignored) {
                }
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void setKeepAwake(final PluginCall call) {
        final boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        final Activity act = getActivity();
        if (act == null) {
            call.resolve();
            return;
        }
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (enabled) {
                        act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                } catch (Exception ignored) {
                }
                call.resolve();
            }
        });
    }

    // ---------------------------------------------------------------- share

    @PluginMethod
    public void shareFile(PluginCall call) {
        String path = call.getString("path");
        String title = call.getString("title", "Share");
        if (path == null) {
            call.reject("path missing");
            return;
        }
        try {
            File f = new File(path);
            if (!f.isFile()) {
                call.reject("File not found");
                return;
            }
            Context ctx = getContext();
            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", f);
            String lower = f.getName().toLowerCase(Locale.ROOT);
            String mime = lower.endsWith(".epub") ? "application/epub+zip" : "application/pdf";
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, title);
            getActivity().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    // ---------------------------------------------------------------- app info + self update

    @PluginMethod
    public void getAppInfo(PluginCall call) {
        try {
            Context ctx = getContext();
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            long code;
            if (Build.VERSION.SDK_INT >= 28) {
                code = pi.getLongVersionCode();
            } else {
                code = pi.versionCode;
            }
            JSObject o = new JSObject();
            o.put("versionName", pi.versionName);
            o.put("versionCode", code);
            o.put("sdk", Build.VERSION.SDK_INT);
            call.resolve(o);
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void downloadAndInstall(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || !url.startsWith("https://")) {
            call.reject("Invalid update url");
            return;
        }
        final Context ctx = getContext();
        if (Build.VERSION.SDK_INT >= 26 && !ctx.getPackageManager().canRequestPackageInstalls()) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + ctx.getPackageName()));
                getActivity().startActivity(i);
            } catch (Exception ignored) {
            }
            JSObject o = new JSObject();
            o.put("needsPermission", true);
            call.resolve(o);
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    String current = url;
                    int redirects = 0;
                    while (true) {
                        conn = (HttpURLConnection) new URL(current).openConnection();
                        conn.setInstanceFollowRedirects(false);
                        conn.setConnectTimeout(20000);
                        conn.setReadTimeout(30000);
                        conn.setRequestProperty("User-Agent", "MyReader-Updater");
                        int code = conn.getResponseCode();
                        if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                            String loc = conn.getHeaderField("Location");
                            conn.disconnect();
                            if (loc == null || ++redirects > 6) {
                                call.reject("Too many redirects");
                                return;
                            }
                            current = loc;
                            continue;
                        }
                        if (code != 200) {
                            call.reject("Download failed: HTTP " + code);
                            return;
                        }
                        break;
                    }
                    long total = conn.getContentLength();
                    File dir = new File(ctx.getCacheDir(), "update");
                    if (!dir.exists()) dir.mkdirs();
                    File[] old = dir.listFiles();
                    if (old != null) {
                        for (File o : old) o.delete();
                    }
                    File apk = new File(dir, "MyReader-update.apk");
                    InputStream in = conn.getInputStream();
                    OutputStream out = new FileOutputStream(apk);
                    long received = 0;
                    long lastEmit = 0;
                    try {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            received += n;
                            long now = System.currentTimeMillis();
                            if (now - lastEmit > 150) {
                                lastEmit = now;
                                JSObject p = new JSObject();
                                p.put("received", received);
                                p.put("total", total);
                                notifyListeners("updateProgress", p);
                            }
                        }
                    } finally {
                        try { out.close(); } catch (Exception ignored) { }
                        try { in.close(); } catch (Exception ignored) { }
                    }
                    JSObject done = new JSObject();
                    done.put("received", received);
                    done.put("total", total > 0 ? total : received);
                    notifyListeners("updateProgress", done);

                    Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", apk);
                    Intent install = new Intent(Intent.ACTION_VIEW);
                    install.setDataAndType(uri, "application/vnd.android.package-archive");
                    install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(install);
                    JSObject res = new JSObject();
                    res.put("installing", true);
                    call.resolve(res);
                } catch (Throwable t) {
                    call.reject(String.valueOf(t.getMessage()));
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }
}

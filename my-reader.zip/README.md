# My Reader

PDF + EPUB reader (Capacitor + Vite). APK is built by GitHub Actions.

1. Repo-র root-এ `.github/workflows/build.yml` রাখুন।
2. এই zip ফাইলটা (extract না করে) repo-র root-এ commit করুন।
3. Actions → "Build My Reader APK" চললে শেষে Releases-এ `MyReader.apk` পাবেন।
4. পরের আপডেট: একই নামে নতুন zip দিয়ে আগেরটা replace করে commit করুন। অ্যাপের Settings → "আপডেট দেখুন" থেকে ইনস্টল হবে।

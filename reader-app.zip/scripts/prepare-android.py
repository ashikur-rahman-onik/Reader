import os, re, shutil, sys
build = os.environ.get("BUILD_NUMBER", "1")
A = "android/app"
pkg_dir = f"{A}/src/main/java/com/sctc/reader"
os.makedirs(pkg_dir, exist_ok=True)
for f in os.listdir("native/java"):
    shutil.copy(f"native/java/{f}", f"{pkg_dir}/{f}")
# remove any other MainActivity generated under a different path
for root, _, files in os.walk(f"{A}/src/main/java"):
    if "MainActivity.java" in files and root != pkg_dir:
        os.remove(os.path.join(root, "MainActivity.java"))
# icons
res = f"{A}/src/main/res"
shutil.rmtree(f"{res}/mipmap-anydpi-v26", ignore_errors=True)
for d in os.listdir("native/res"):
    os.makedirs(f"{res}/{d}", exist_ok=True)
    for f in os.listdir(f"native/res/{d}"):
        shutil.copy(f"native/res/{d}/{f}", f"{res}/{d}/{f}")
# manifest
mp = f"{A}/src/main/AndroidManifest.xml"
m = open(mp, encoding="utf-8").read()
perms = ('<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />\n'
         '    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />\n    ')
if "MANAGE_EXTERNAL_STORAGE" not in m:
    m = m.replace("<application", perms + "<application", 1)
    m = m.replace("<application", '<application android:requestLegacyExternalStorage="true" android:largeHeap="true"', 1)
open(mp, "w", encoding="utf-8").write(m)
# gradle
gp = f"{A}/build.gradle"
g = open(gp, encoding="utf-8").read()
g = re.sub(r"versionCode\s+\d+", f"versionCode {build}", g, count=1)
g = re.sub(r'versionName\s+"[^"]*"', f'versionName "1.0.{build}"', g, count=1)
if "checkReleaseBuilds" not in g:
    g += "\nandroid {\n    lint {\n        checkReleaseBuilds false\n        abortOnError false\n    }\n}\n"
open(gp, "w", encoding="utf-8").write(g)
print("android prepared, build", build)

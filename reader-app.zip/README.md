# Reader
PDF / e-book reader with full-screen page-curl, history, device scan, share and in-app updates.
Upload this zip + .github/workflows/build.yml to a PUBLIC GitHub repo; Actions builds Reader.apk and publishes a Release.

package com.sctc.reader;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.util.ArrayDeque;

@CapacitorPlugin(name = "ReaderStorage")
public class StoragePlugin extends Plugin {

    private boolean granted() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        }
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void hasAccess(PluginCall call) {
        JSObject o = new JSObject();
        o.put("granted", granted());
        call.resolve(o);
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + getContext().getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                } catch (Exception e) {
                    Intent i = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(i);
                }
            } else {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 7001);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void scan(final PluginCall call) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSArray arr = new JSArray();
                    File root = Environment.getExternalStorageDirectory();
                    ArrayDeque<File> stack = new ArrayDeque<File>();
                    stack.push(root);
                    int count = 0;
                    while (!stack.isEmpty() && count < 8000) {
                        File dir = stack.pop();
                        File[] list = dir.listFiles();
                        if (list == null) continue;
                        for (File f : list) {
                            String n = f.getName();
                            if (f.isDirectory()) {
                                if (n.startsWith(".")) continue;
                                if (dir.equals(root) && n.equals("Android")) continue;
                                stack.push(f);
                            } else if (n.toLowerCase().endsWith(".pdf")) {
                                JSObject o = new JSObject();
                                o.put("path", f.getAbsolutePath());
                                o.put("name", n);
                                o.put("size", f.length());
                                o.put("modified", f.lastModified());
                                arr.put(o);
                                count++;
                            }
                        }
                    }
                    JSObject ret = new JSObject();
                    ret.put("files", arr);
                    call.resolve(ret);
                } catch (Exception e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }

    @PluginMethod
    public void setImmersive(final PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                View v = getActivity().getWindow().getDecorView();
                if (on) {
                    v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                } else {
                    v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                }
                call.resolve();
            }
        });
    }
}

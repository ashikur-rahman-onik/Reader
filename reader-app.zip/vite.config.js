import { defineConfig } from 'vite';
export default defineConfig({
  base: './',
  define: {
    __BUILD__: JSON.stringify(process.env.VITE_BUILD || '0'),
    __REPO__: JSON.stringify(process.env.VITE_REPO || '')
  },
  build: { outDir: 'dist', target: 'es2018', chunkSizeWarningLimit: 4000 }
});

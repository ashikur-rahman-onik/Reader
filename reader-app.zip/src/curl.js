// Page-curl renderer: folds the corner of page A (reflecting it) and reveals page B beneath.
// All coordinates are canvas (device) pixels. C = anchor corner, P = dragged corner position.

function clipPoly(poly, nx, ny, d0, sign) {
  const out = [];
  const s = (p) => sign * (p[0] * nx + p[1] * ny - d0);
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const sa = s(a), sb = s(b);
    if (sa >= 0) out.push(a);
    if ((sa >= 0) !== (sb >= 0)) {
      const t = sa / (sa - sb);
      out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
    }
  }
  return out;
}

function tracePath(ctx, poly) {
  ctx.beginPath();
  ctx.moveTo(poly[0][0], poly[0][1]);
  for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0], poly[i][1]);
  ctx.closePath();
}

export function drawCurl(ctx, A, B, C, P, paper, dpr) {
  const W = ctx.canvas.width, H = ctx.canvas.height;
  let nx = P.x - C.x, ny = P.y - C.y;
  const L = Math.hypot(nx, ny);
  ctx.clearRect(0, 0, W, H);
  if (L < 2) { ctx.drawImage(A, 0, 0); return; }
  nx /= L; ny /= L;
  const mx = (P.x + C.x) / 2, my = (P.y + C.y) / 2;
  const d0 = mx * nx + my * ny;
  const rect = [[0, 0], [W, 0], [W, H], [0, H]];
  const flat = clipPoly(rect, nx, ny, d0, 1);
  const folded = clipPoly(rect, nx, ny, d0, -1);
  const sw = 46 * dpr;

  // 1) page underneath
  ctx.drawImage(B, 0, 0);
  if (folded.length > 2) {
    ctx.save();
    tracePath(ctx, folded); ctx.clip();
    const g = ctx.createLinearGradient(mx, my, mx - nx * sw, my - ny * sw);
    g.addColorStop(0, 'rgba(0,0,0,0.42)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }

  // 2) flat part of the current page
  if (flat.length > 2) {
    ctx.save();
    tracePath(ctx, flat); ctx.clip();
    ctx.drawImage(A, 0, 0);
    const g = ctx.createLinearGradient(mx, my, mx + nx * sw, my + ny * sw);
    g.addColorStop(0, 'rgba(0,0,0,0.38)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }

  // 3) the folded-over back of the page (reflection across the fold line)
  if (folded.length > 2) {
    const refl = folded.map((p) => {
      const k = 2 * (p[0] * nx + p[1] * ny - d0);
      return [p[0] - k * nx, p[1] - k * ny];
    });
    ctx.save();
    tracePath(ctx, rect); ctx.clip();
    tracePath(ctx, refl); ctx.clip();
    ctx.save();
    ctx.transform(1 - 2 * nx * nx, -2 * nx * ny, -2 * nx * ny, 1 - 2 * ny * ny, 2 * d0 * nx, 2 * d0 * ny);
    ctx.drawImage(A, 0, 0);
    ctx.restore();
    ctx.fillStyle = paper; ctx.globalAlpha = 0.86; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
    const g = ctx.createLinearGradient(mx, my, P.x, P.y);
    g.addColorStop(0, 'rgba(0,0,0,0.30)');
    g.addColorStop(0.12, 'rgba(0,0,0,0.06)');
    g.addColorStop(0.7, 'rgba(255,255,255,0.10)');
    g.addColorStop(1, 'rgba(0,0,0,0.12)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }
}

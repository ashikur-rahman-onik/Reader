const K_HIST = 'rd.history', K_SET = 'rd.settings';
const read = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };

export const settings = Object.assign({ lang: 'bn', theme: 'day', curl: true }, read(K_SET, {}));
export const saveSettings = () => write(K_SET, settings);

let hist = read(K_HIST, []);
export const getHistory = () => hist.slice().sort((a, b) => b.last - a.last);
export const findRec = (path) => hist.find((r) => r.path === path);
export function upsertRec(rec) {
  const i = hist.findIndex((r) => r.path === rec.path);
  if (i >= 0) hist[i] = rec; else hist.push(rec);
  if (hist.length > 120) hist = getHistory().slice(0, 120);
  if (!write(K_HIST, hist)) { hist.forEach((r) => { if (r !== rec) delete r.cover; }); write(K_HIST, hist); }
}
export function removeRec(path) { hist = hist.filter((r) => r.path !== path); write(K_HIST, hist); }
export function clearHistory() { hist = []; write(K_HIST, hist); }

const S = {
  en: {
    recent: 'Library', files: 'Files', settings: 'Settings', cont: 'Continue reading', recents: 'Recent',
    emptyT: 'Your shelf is empty', emptyS: 'Open a PDF or let Reader find the PDFs on your phone.', open: 'Open a PDF',
    page: 'Page', of: 'of', search: 'Search PDFs', allowT: 'Allow access to your files', allowS: 'Reader needs "All files access" to find every PDF on your phone. Nothing leaves your device.',
    allow: 'Allow access', scanning: 'Scanning your phone…', rescan: 'Rescan', none: 'No PDF found', sName: 'Name', sDate: 'Date', sSize: 'Size',
    goto: 'Go to page', go: 'Go', marks: 'Bookmarks', noMarks: 'No bookmarks yet', share: 'Share', remove: 'Remove from history', cancel: 'Cancel',
    day: 'Day', sepia: 'Sepia', night: 'Night', theme: 'Reading theme', curl: 'Page curl animation', lang: 'Language', update: 'App update', check: 'Check for update',
    upToDate: 'You have the latest version', updFail: 'Could not check. Check internet / repo is public.', updAvail: 'New version available', updNow: 'Update now', later: 'Later',
    version: 'Version', clear: 'Clear history', cleared: 'History cleared', loading: 'Opening…', fail: 'Could not open this PDF', pass: 'This PDF is password protected. Enter password:',
    shareFail: 'Could not share this file', bmOn: 'Bookmarked', bmOff: 'Bookmark removed', webOnly: 'Device scan works in the installed app. Use "Open a PDF" here.', updHint: 'After download, tap the file to install over the old app.',
    zoom: 'Zoom', size: 'File size', appearance: 'Reading', about: 'About'
  },
  bn: {
    recent: 'লাইব্রেরি', files: 'ফাইল', settings: 'সেটিংস', cont: 'পড়া চালিয়ে যান', recents: 'সাম্প্রতিক',
    emptyT: 'তোমার তাক এখনো খালি', emptyS: 'একটি PDF খোলো, অথবা ফোনের সব PDF Reader-কে খুঁজে নিতে দাও।', open: 'PDF খোলো',
    page: 'পৃষ্ঠা', of: '/', search: 'PDF খুঁজুন', allowT: 'ফাইল অ্যাক্সেসের অনুমতি দাও', allowS: 'ফোনের সব PDF খুঁজে পেতে Reader-এর "All files access" লাগবে। কিছুই ফোনের বাইরে যায় না।',
    allow: 'অনুমতি দিন', scanning: 'ফোন স্ক্যান হচ্ছে…', rescan: 'আবার স্ক্যান', none: 'কোনো PDF পাওয়া যায়নি', sName: 'নাম', sDate: 'তারিখ', sSize: 'সাইজ',
    goto: 'পৃষ্ঠায় যান', go: 'যান', marks: 'বুকমার্ক', noMarks: 'এখনো কোনো বুকমার্ক নেই', share: 'শেয়ার', remove: 'হিস্টোরি থেকে সরান', cancel: 'বাতিল',
    day: 'দিন', sepia: 'সেপিয়া', night: 'রাত', theme: 'পড়ার থিম', curl: 'পেজ কার্ল অ্যানিমেশন', lang: 'ভাষা', update: 'অ্যাপ আপডেট', check: 'আপডেট চেক করুন',
    upToDate: 'তোমার কাছে সর্বশেষ ভার্সন আছে', updFail: 'চেক করা যায়নি। ইন্টারনেট/রিপো পাবলিক কিনা দেখো।', updAvail: 'নতুন ভার্সন এসেছে', updNow: 'এখনই আপডেট', later: 'পরে',
    version: 'ভার্সন', clear: 'হিস্টোরি মুছুন', cleared: 'হিস্টোরি মোছা হয়েছে', loading: 'খোলা হচ্ছে…', fail: 'এই PDF খোলা যায়নি', pass: 'এই PDF-এ পাসওয়ার্ড আছে। পাসওয়ার্ড দাও:',
    shareFail: 'ফাইলটি শেয়ার করা যায়নি', bmOn: 'বুকমার্ক হয়েছে', bmOff: 'বুকমার্ক সরানো হয়েছে', webOnly: 'ডিভাইস স্ক্যান ইনস্টল করা অ্যাপে কাজ করে। এখানে "PDF খোলো" ব্যবহার করো।', updHint: 'ডাউনলোড শেষে ফাইলে ট্যাপ করলে পুরনো অ্যাপের ওপরেই ইনস্টল হবে।',
    zoom: 'জুম', size: 'ফাইল সাইজ', appearance: 'পড়া', about: 'পরিচিতি'
  }
};
export const t = (k) => (S[settings.lang] && S[settings.lang][k]) || S.en[k] || k;

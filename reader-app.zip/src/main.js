import './style.css';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { Share } from '@capacitor/share';
import { Browser } from '@capacitor/browser';
import { StatusBar, Style } from '@capacitor/status-bar';
import * as pdfNs from 'pdfjs-dist';
import workerSrc from 'pdfjs-dist/build/pdf.worker.min.js?url';
import logoMark from './assets/logo-mark.png';
import { drawCurl } from './curl.js';
import { settings, saveSettings, getHistory, findRec, upsertRec, removeRec, clearHistory, t } from './store.js';

const pdfjs = pdfNs.getDocument ? pdfNs : pdfNs.default;
pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;

const native = Capacitor.isNativePlatform();
const RS = registerPlugin('ReaderStorage');
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const PAPER = { day: '#ffffff', sepia: '#f1e4c4', night: '#000000' };
const ICONS = {
  book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z"/><path d="M20 17v4H6.5A2.5 2.5 0 0 1 4 18.5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  gear: '<path d="M4 6h10M18 6h2M4 12h2M10 12h10M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>',
  back: '<path d="M15 5l-7 7 7 7"/>', next: '<path d="M9 5l7 7-7 7"/>',
  mark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  share: '<circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.4M8.2 13.2l7.6 4.4"/>',
  zoom: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5M11 8v6M8 11h6"/>',
  more: '<circle cx="5" cy="12" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="19" cy="12" r="1.7"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  pdf: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/>',
  list: '<path d="M4 6h16M4 12h16M4 18h10"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  down: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>'
};
const ic = (n, cls) => `<svg viewBox="0 0 24 24"${cls ? ` class="${cls}"` : ''}${n === 'more' ? ' fill="currentColor" stroke="none"' : ''}>${ICONS[n]}</svg>`;
const fmtSize = (b) => (!b ? '' : b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
const title = (n) => String(n || '').replace(/\.pdf$/i, '');
const bn = (n) => (settings.lang === 'bn' ? String(n).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[d]) : String(n));
const pct = (r) => (r.total ? Math.round((r.page / r.total) * 100) : 0);
let toastT = 0;
function toast(msg) {
  const el = $('toast'); el.textContent = msg; el.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('on'), 2600);
}

/* ---------- sheet ---------- */
function openSheet(html) { $('sheet').innerHTML = html; $('sheetWrap').hidden = false; }
function closeSheet() { $('sheetWrap').hidden = true; $('sheet').innerHTML = ''; }
$('scrim').addEventListener('click', closeSheet);

/* ---------- home / tabs ---------- */
let tab = 'recent';
const F = { granted: null, list: [], loading: false, q: '', sort: 'date', view: [] };

function renderNav() {
  const items = [['recent', 'book', t('recent')], ['files', 'folder', t('files')], ['settings', 'gear', t('settings')]];
  $('nav').innerHTML = items.map(([k, i, l]) => `<button data-act="tab" data-tab="${k}" class="${tab === k ? 'on' : ''}">${ic(i)}<span>${l}</span></button>`).join('');
}
function setTab(k) {
  tab = k; renderNav();
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('on', v.id === 'v-' + k));
  if (k === 'recent') renderRecent(); else if (k === 'files') loadFiles(false); else renderSettings();
}
function recRow(r) {
  return `<div class="row glass" data-act="openrec" data-path="${esc(r.path)}">
    <div class="th" style="${r.cover ? `background-image:url(${r.cover})` : ''}">${r.cover ? '' : ic('pdf')}</div>
    <div class="tx"><div class="nm">${esc(title(r.name))}</div>
    <div class="sub">${t('page')} ${bn(r.page)} ${t('of')} ${bn(r.total || '?')}${r.size ? ' · ' + bn(fmtSize(r.size)) : ''}</div>
    <div class="bar" style="margin-top:7px"><i style="width:${pct(r)}%"></i></div></div>
    <button class="ibtn" data-act="recmenu" data-path="${esc(r.path)}">${ic('more')}</button></div>`;
}
function renderRecent() {
  const h = getHistory(); const v = $('v-recent');
  if (!h.length) {
    v.innerHTML = `<div class="empty"><img src="${logoMark}" alt=""/><h3>${t('emptyT')}</h3><p>${t('emptyS')}</p>
      <button class="btn" data-act="pick">${ic('plus')}${t('open')}</button>
      ${native ? `<div style="height:10px"></div><button class="btn ghost" data-act="tab" data-tab="files">${ic('folder')}${t('files')}</button>` : ''}</div>`;
    return;
  }
  const c = h[0];
  v.innerHTML = `<div class="hero glass" data-act="openrec" data-path="${esc(c.path)}">
    <div class="cov" style="${c.cover ? `background-image:url(${c.cover})` : ''}">${c.cover ? '' : ic('pdf')}</div>
    <div class="info"><div><small>${t('cont')}</small><h3>${esc(title(c.name))}</h3>
    <div class="meta">${t('page')} ${bn(c.page)} ${t('of')} ${bn(c.total || '?')} · ${bn(pct(c))}%</div></div>
    <div class="bar"><i style="width:${pct(c)}%"></i></div></div></div>
    <h2>${t('recents')}</h2>${h.slice(1).map(recRow).join('')}`;
}
async function loadFiles(force) {
  if (!native) { F.granted = false; renderFiles(); return; }
  try {
    F.granted = (await RS.hasAccess()).granted;
    if (F.granted && (force || !F.list.length) && !F.loading) {
      F.loading = true; renderFiles();
      try { F.list = (await RS.scan()).files || []; } catch (e) { F.list = []; }
      F.loading = false;
    }
  } catch (e) { F.granted = false; F.loading = false; }
  if (tab === 'files') renderFiles();
}
function renderFiles() {
  const v = $('v-files');
  if (!F.granted) {
    v.innerHTML = `<div class="card glass" style="text-align:center;margin-top:30px">
      <div style="font-size:42px;margin-bottom:8px">${ic('folder')}</div><h3 style="margin-bottom:8px">${t('allowT')}</h3>
      <p class="meta" style="line-height:1.5;margin-bottom:16px">${native ? t('allowS') : t('webOnly')}</p>
      ${native ? `<button class="btn" data-act="allow">${t('allow')}</button>` : `<button class="btn" data-act="pick">${t('open')}</button>`}</div>`;
    return;
  }
  v.innerHTML = `<div class="search glass">${ic('search')}<input id="fq" placeholder="${t('search')}" value="${esc(F.q)}"/></div>
    <div class="chips">${[['date', 'sDate'], ['name', 'sName'], ['size', 'sSize']].map(([k, l]) => `<button class="chip ${F.sort === k ? 'on' : ''}" data-act="sort" data-k="${k}">${t(l)}</button>`).join('')}
    <span class="grow"></span><button class="ibtn" data-act="rescan" aria-label="${t('rescan')}">${ic('refresh')}</button></div><div id="fl"></div>`;
  $('fq').addEventListener('input', (e) => { F.q = e.target.value; fillFiles(); });
  fillFiles();
}
function fillFiles() {
  const box = $('fl'); if (!box) return;
  if (F.loading) { box.innerHTML = `<div class="empty"><div class="spin" style="margin:0 auto 14px"></div>${t('scanning')}</div>`; return; }
  const q = F.q.trim().toLowerCase();
  let a = F.list.filter((f) => !q || f.name.toLowerCase().includes(q));
  a.sort(F.sort === 'name' ? (x, y) => x.name.localeCompare(y.name) : F.sort === 'size' ? (x, y) => y.size - x.size : (x, y) => y.modified - x.modified);
  F.view = a.slice(0, 400);
  if (!a.length) { box.innerHTML = `<div class="empty">${t('none')}</div>`; return; }
  const loc = settings.lang === 'bn' ? 'bn-BD' : 'en-GB';
  box.innerHTML = F.view.map((f, i) => {
    const dir = f.path.replace(/^\/storage\/emulated\/0\//, '').split('/').slice(0, -1).join('/') || '/';
    return `<div class="row glass" data-act="openfile" data-i="${i}"><div class="th pdf">${ic('pdf')}</div>
      <div class="tx"><div class="nm">${esc(title(f.name))}</div><div class="sub">${esc(dir)} · ${bn(fmtSize(f.size))} · ${new Date(f.modified).toLocaleDateString(loc)}</div></div>
      <button class="ibtn" data-act="filemenu" data-i="${i}">${ic('more')}</button></div>`;
  }).join('');
}
function seg(key, opts, cur) { return `<div class="seg">${opts.map(([v, l]) => `<button data-act="set" data-key="${key}" data-val="${v}" class="${cur === v ? 'on' : ''}">${l}</button>`).join('')}</div>`; }
function renderSettings() {
  $('v-settings').innerHTML = `
  <div class="card glass"><h3 style="margin-bottom:12px">${t('appearance')}</h3>
    <div class="meta" style="margin:0 0 8px">${t('theme')}</div>${seg('theme', [['day', t('day')], ['sepia', t('sepia')], ['night', t('night')]], settings.theme)}
    <div class="set" style="margin-top:8px"><span>${t('curl')}</span><button class="sw ${settings.curl ? 'on' : ''}" data-act="curlsw" aria-label="curl"></button></div>
    <div class="meta" style="margin:8px 0">${t('lang')}</div>${seg('lang', [['bn', 'বাংলা'], ['en', 'English']], settings.lang)}</div>
  <div class="card glass"><h3 style="margin-bottom:6px">${t('update')}</h3>
    <div class="meta" style="margin:0 0 12px">${t('version')} 1.0.${esc(__BUILD__)}</div>
    <button class="btn" data-act="checkupd">${ic('refresh')}${t('check')}</button></div>
  <div class="card glass"><button class="li" data-act="clearhist">${ic('trash')}${t('clear')}</button></div>
  <div class="about">Reader · Sabuj Computer Training Center</div>`;
}

/* ---------- reader ---------- */
const stage = $('stage'); const sctx = stage.getContext('2d');
const R = { doc: null, n: 0, page: 1, rec: null, cache: new Map(), pend: new Map(), gen: 0, W: 0, H: 0, Wd: 0, Hd: 0, dpr: 1, drag: null, anim: null, zoom: 2, open: false, opening: false };
const valid = (p) => p >= 1 && p <= R.n;

function sizeStage() {
  const el = $('reader'); R.W = el.clientWidth; R.H = el.clientHeight;
  R.dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  R.Wd = stage.width = Math.max(1, Math.round(R.W * R.dpr));
  R.Hd = stage.height = Math.max(1, Math.round(R.H * R.dpr));
}
async function renderTo(p, tw, th, contain, theme) {
  theme = theme || settings.theme;
  const doc = R.doc; const page = await doc.getPage(p);
  const v1 = page.getViewport({ scale: 1 });
  const s = contain ? Math.min(tw / v1.width, th / v1.height) : tw / v1.width;
  const vp = page.getViewport({ scale: s });
  const off = document.createElement('canvas'); off.width = Math.max(1, Math.ceil(vp.width)); off.height = Math.max(1, Math.ceil(vp.height));
  const o = off.getContext('2d'); o.fillStyle = '#fff'; o.fillRect(0, 0, off.width, off.height);
  await page.render({ canvasContext: o, viewport: vp }).promise;
  if (theme === 'night') {
    o.globalCompositeOperation = 'difference'; o.fillStyle = '#fff'; o.fillRect(0, 0, off.width, off.height);
    o.globalCompositeOperation = 'multiply'; o.fillStyle = '#d3dae6'; o.fillRect(0, 0, off.width, off.height);
  } else if (theme === 'sepia') {
    o.globalCompositeOperation = 'multiply'; o.fillStyle = PAPER.sepia; o.fillRect(0, 0, off.width, off.height);
  }
  if (!contain) return off;
  const cv = document.createElement('canvas'); cv.width = tw; cv.height = th;
  const c = cv.getContext('2d'); c.fillStyle = PAPER[theme]; c.fillRect(0, 0, tw, th);
  c.drawImage(off, Math.round((tw - off.width) / 2), Math.round((th - off.height) / 2));
  return cv;
}
function getBitmap(p) {
  if (R.cache.has(p)) return Promise.resolve(R.cache.get(p));
  if (R.pend.has(p)) return R.pend.get(p);
  const gen = R.gen;
  const pr = renderTo(p, R.Wd, R.Hd, true).then((cv) => {
    if (gen === R.gen) {
      R.cache.set(p, cv); R.pend.delete(p);
      for (const k of Array.from(R.cache.keys())) if (Math.abs(k - R.page) > 2 && Math.abs(k - p) > 2) R.cache.delete(k);
    }
    return cv;
  }, (e) => { R.pend.delete(p); throw e; });
  R.pend.set(p, pr); return pr;
}
function prefetch() { [R.page + 1, R.page - 1, R.page + 2].forEach((p) => { if (valid(p)) getBitmap(p).catch(() => {}); }); }
function paint() {
  const A = R.cache.get(R.page); if (!A) return;
  const d = R.drag; const a = R.anim; let P, C, tg;
  if (a) { P = a.P; C = a.C; tg = a.target; } else if (d && d.moved && !d.blocked && d.P) { P = d.P; C = d.C; tg = d.target; }
  if (P) { const B = R.cache.get(tg); if (B) { drawCurl(sctx, A, B, C, P, PAPER[settings.theme], R.dpr); return; } }
  sctx.drawImage(A, 0, 0);
}
let rafP = 0;
function sched() { if (rafP) return; rafP = requestAnimationFrame(() => { rafP = 0; paint(); }); }
async function showPage() {
  const gen = R.gen, p = R.page;
  try { await getBitmap(p); } catch (e) { toast(t('fail')); return; }
  if (gen !== R.gen || p !== R.page) return;
  paint(); updateChrome(); prefetch();
}
let persistT = 0;
function persist(now) {
  if (!R.rec || !R.rec.path) return;
  R.rec.page = R.page; R.rec.total = R.n; R.rec.last = Date.now();
  clearTimeout(persistT);
  const run = () => upsertRec(R.rec);
  if (now) run(); else persistT = setTimeout(run, 500);
}
function renderChrome() {
  $('rTop').innerHTML = `<button class="ibtn" data-act="rclose">${ic('back')}</button><div class="ttl">${esc(title(R.rec.name))}</div>
    <button class="ibtn" id="bmBtn" data-act="bm">${ic('mark')}</button><button class="ibtn" data-act="zoomopen">${ic('zoom')}</button><button class="ibtn" data-act="rmenu">${ic('list')}</button>`;
  $('rBot').innerHTML = `<div class="pg"><span id="pgL"></span><span id="pgR"></span></div><input type="range" id="slider" min="1" max="${R.n}" value="${R.page}"/>`;
  const s = $('slider');
  s.addEventListener('input', () => { $('pgL').textContent = `${t('page')} ${bn(s.value)} ${t('of')} ${bn(R.n)}`; });
  s.addEventListener('change', () => jump(parseInt(s.value, 10)));
}
function updateChrome() {
  if (!R.rec) return;
  const pl = $('pgL'); if (!pl) return;
  pl.textContent = `${t('page')} ${bn(R.page)} ${t('of')} ${bn(R.n)}`;
  $('pgR').textContent = bn(Math.round((R.page / R.n) * 100)) + '%';
  $('slider').value = R.page;
  const on = (R.rec.marks || []).includes(R.page);
  $('bmBtn').classList.toggle('act', on);
  $('bmBtn').querySelector('svg').style.fill = on ? 'currentColor' : 'none';
}
async function jump(p) {
  p = Math.min(R.n, Math.max(1, p || 1)); if (p === R.page) { updateChrome(); return; }
  R.page = p; persist(); await showPage();
}
function setImmersive(on) { if (native) RS.setImmersive({ on }).catch(() => {}); }

async function openPdf({ path, name, size, file }) {
  if (R.opening) return; R.opening = true; $('rLoad').hidden = false; $('reader').hidden = false;
  try {
    let buf;
    if (file) buf = await file.arrayBuffer();
    else {
      const url = Capacitor.convertFileSrc('file://' + path.split('/').map(encodeURIComponent).join('/'));
      const r = await fetch(url); if (!r.ok) throw new Error('read'); buf = await r.arrayBuffer();
    }
    const task = pdfjs.getDocument({ data: new Uint8Array(buf) });
    task.onPassword = (cb) => { const pw = window.prompt(t('pass')); if (pw == null) task.destroy(); else cb(pw); };
    const doc = await task.promise;
    if (R.doc) { try { R.doc.destroy(); } catch (e) {} }
    R.doc = doc; R.n = doc.numPages; R.gen++; R.cache.clear(); R.pend.clear(); R.anim = null; R.drag = null;
    R.rec = (path && findRec(path)) || { path: path || null, name: name || file.name, size: size || (file && file.size) || 0, page: 1, total: R.n, last: Date.now(), marks: [] };
    R.rec.marks = R.rec.marks || []; R.rec.total = R.n;
    R.page = Math.min(R.n, Math.max(1, R.rec.page || 1));
    R.open = true; $('reader').classList.remove('nochrome'); $('zoom').hidden = true;
    setImmersive(true);
    await new Promise((r) => setTimeout(r, native ? 160 : 0));
    sizeStage(); renderChrome();
    await showPage(); persist(true);
    if (!R.rec.cover && R.rec.path) makeCover(R.gen);
    setTimeout(() => $('reader').classList.add('nochrome'), 1800);
  } catch (e) {
    $('reader').hidden = true; R.open = false; setImmersive(false);
    toast(t('fail'));
  } finally { R.opening = false; $('rLoad').hidden = true; }
}
async function makeCover(gen) {
  try {
    const cv = await renderTo(1, 150, 0, false, 'day');
    if (gen !== R.gen || !R.rec) return;
    R.rec.cover = cv.toDataURL('image/jpeg', 0.7); persist();
  } catch (e) {}
}
function closeReader() {
  if (!R.open) return;
  persist(true); R.open = false; R.gen++; R.cache.clear(); R.pend.clear(); R.drag = null; R.anim = null;
  $('reader').hidden = true; $('zoom').hidden = true; setImmersive(false);
  if (R.doc) { try { R.doc.destroy(); } catch (e) {} R.doc = null; }
  R.rec = null; closeSheet(); renderRecent();
}
function setTheme(th) {
  settings.theme = th; saveSettings();
  if (R.open) { R.gen++; R.cache.clear(); R.pend.clear(); showPage(); if (!$('zoom').hidden) renderZoom(); }
}

/* gestures + page curl */
const pt = (e) => { const r = stage.getBoundingClientRect(); return { x: (e.clientX - r.left) * (stage.width / r.width), y: (e.clientY - r.top) * (stage.height / r.height) }; };
stage.addEventListener('pointerdown', (e) => {
  if (!R.doc || R.anim) return;
  try { stage.setPointerCapture(e.pointerId); } catch (x) {}
  const p = pt(e); R.drag = { s: p, moved: false, dir: 0, vx: 0, lx: p.x, lt: performance.now(), dx: 0 };
});
stage.addEventListener('pointermove', (e) => {
  const d = R.drag; if (!d) return;
  const p = pt(e), dx = p.x - d.s.x, dy = p.y - d.s.y, now = performance.now();
  if (!d.moved) {
    if (Math.hypot(dx, dy) < 12 * R.dpr) return;
    d.moved = true; d.dir = dx < 0 ? 1 : -1; d.target = R.page + d.dir;
    d.simple = !settings.curl; d.blocked = !valid(d.target) || d.simple;
    d.C = { x: d.dir > 0 ? R.Wd : 0, y: d.s.y > R.Hd / 2 ? R.Hd : 0 };
    if (!d.blocked) getBitmap(d.target).then(sched, () => {});
  }
  d.vx = 0.7 * d.vx + 0.3 * ((p.x - d.lx) / Math.max(1, now - d.lt)); d.lx = p.x; d.lt = now; d.dx = dx;
  if (d.blocked) return;
  let px = d.C.x + dx * 2, py = d.C.y + dy * 1.4;
  px = d.dir > 0 ? Math.min(d.C.x, Math.max(-R.Wd, px)) : Math.max(d.C.x, Math.min(2 * R.Wd, px));
  py = d.C.y === R.Hd ? Math.min(R.Hd, Math.max(R.Hd * 0.35, py)) : Math.max(0, Math.min(R.Hd * 0.65, py));
  d.P = { x: px, y: py }; sched();
});
function release() {
  const d = R.drag; R.drag = null; if (!d) return;
  if (!d.moved) { tap(d.s); return; }
  const mag = -d.dir * d.dx;
  if (d.simple) { if (mag > R.Wd * 0.1 && valid(d.target)) jump(d.target); return; }
  if (d.blocked || !d.P) { sched(); return; }
  settle(d.C, d.P, d.dir, d.target, mag > R.Wd * 0.22 || -d.dir * d.vx > 0.45 * R.dpr);
}
stage.addEventListener('pointerup', release);
stage.addEventListener('pointercancel', release);
function animate(C, from, to, target, ms, arc) {
  R.anim = { C, P: from, target };
  const t0 = performance.now(), sg = C.y === R.Hd ? -1 : 1;
  return new Promise((res) => {
    const step = (now) => {
      if (!R.anim) { res(); return; }
      const k = Math.min(1, Math.max(0, (now - t0) / ms)), e = 0.5 - 0.5 * Math.cos(Math.PI * k);
      R.anim.P = { x: from.x + (to.x - from.x) * e, y: from.y + (to.y - from.y) * e + sg * arc * Math.sin(Math.PI * e) };
      paint();
      if (k < 1) requestAnimationFrame(step); else res();
    };
    requestAnimationFrame(step);
  });
}
async function settle(C, from, dir, target, commit) {
  if (commit) { try { await getBitmap(target); } catch (e) { return; } }
  const to = commit ? { x: dir > 0 ? -R.Wd - 2 : 2 * R.Wd + 2, y: C.y } : { x: C.x, y: C.y };
  await animate(C, from, to, target, commit ? 380 : 240, 0);
  if (commit && R.open) { R.page = target; persist(); }
  R.anim = null; paint(); updateChrome(); prefetch();
}
async function turn(dir, y) {
  const target = R.page + dir; if (!valid(target) || R.anim) return;
  try { await getBitmap(target); } catch (e) { return; }
  if (!settings.curl) { jump(target); return; }
  const C = { x: dir > 0 ? R.Wd : 0, y: y > R.Hd / 2 ? R.Hd : 0 };
  await animate(C, { x: C.x - dir * 2, y: C.y }, { x: dir > 0 ? -R.Wd - 2 : 2 * R.Wd + 2, y: C.y }, target, 600, R.Hd * 0.1);
  if (R.open) { R.page = target; persist(); }
  R.anim = null; paint(); updateChrome(); prefetch();
}
function tap(p) {
  const x = p.x / R.Wd;
  if (x > 0.7) turn(1, p.y); else if (x < 0.3) turn(-1, p.y);
  else $('reader').classList.toggle('nochrome');
}

/* zoom */
let zgen = 0;
async function renderZoom() {
  const g = ++zgen, zd = Math.min(R.dpr, 2);
  try {
    const cv = await renderTo(R.page, Math.round(R.W * zd * R.zoom), 0, false);
    if (g !== zgen) return;
    cv.style.width = cv.width / zd + 'px'; cv.style.height = cv.height / zd + 'px';
    const box = $('zoomBox'); box.innerHTML = ''; box.appendChild(cv); box.scrollTop = 0; box.scrollLeft = 0;
  } catch (e) { toast(t('fail')); }
  $('zl').textContent = '×' + R.zoom;
}
function openZoom() {
  $('zoom').hidden = false;
  $('zoomBar').innerHTML = `<button class="ibtn" data-act="zprev">${ic('back')}</button><button class="ibtn" data-act="zout">${ic('minus')}</button><span class="z" id="zl">×${R.zoom}</span><button class="ibtn" data-act="zin">${ic('plus')}</button><button class="ibtn" data-act="znext">${ic('next')}</button><button class="ibtn" data-act="zclose">${ic('x')}</button>`;
  renderZoom();
}
function closeZoom() { $('zoom').hidden = true; $('zoomBox').innerHTML = ''; zgen++; paint(); }
async function zoomPage(d) { const p = R.page + d; if (!valid(p)) return; R.page = p; persist(); renderZoom(); updateChrome(); getBitmap(p).then(() => {}, () => {}); }

/* reader menu */
function readerMenu() {
  const marks = (R.rec.marks || []).slice().sort((a, b) => a - b);
  openSheet(`<h3>${esc(title(R.rec.name))}</h3>
    <div class="gt"><input id="gp" type="number" inputmode="numeric" min="1" max="${R.n}" placeholder="${t('goto')} (1–${R.n})"/><button class="btn" data-act="gopage">${t('go')}</button></div>
    <div class="meta" style="margin:0 0 8px">${t('theme')}</div>${seg('theme', [['day', t('day')], ['sepia', t('sepia')], ['night', t('night')]], settings.theme)}
    <div class="set"><span>${t('curl')}</span><button class="sw ${settings.curl ? 'on' : ''}" data-act="curlsw"></button></div>
    <div class="meta" style="margin:8px 0">${t('marks')}</div>
    ${marks.length ? `<div class="chips" style="flex-wrap:wrap">${marks.map((m) => `<button class="chip" data-act="gomark" data-p="${m}">${t('page')} ${bn(m)}</button>`).join('')}</div>` : `<div class="meta">${t('noMarks')}</div>`}
    ${R.rec.path ? `<button class="li" data-act="sharecur">${ic('share')}${t('share')}</button>` : ''}`);
}
async function shareFile(path, name) {
  try { await Share.share({ title: title(name), dialogTitle: title(name), files: [encodeURI('file://' + path)] }); }
  catch (e) { if (!/cancel/i.test(String(e && e.message))) toast(t('shareFail')); }
}

/* update checker (GitHub Releases) */
async function checkUpdate(manual) {
  if (!__REPO__) { if (manual) toast(t('updFail')); return; }
  try {
    const r = await fetch(`https://api.github.com/repos/${__REPO__}/releases/latest`, { headers: { Accept: 'application/vnd.github+json' } });
    if (!r.ok) throw new Error('http');
    const j = await r.json();
    const latest = parseInt(String(j.tag_name || '').replace(/\D/g, ''), 10) || 0, cur = parseInt(__BUILD__, 10) || 0;
    const asset = (j.assets || []).find((a) => /\.apk$/i.test(a.name));
    localStorage.setItem('rd.upd', String(Date.now()));
    if (latest > cur && asset) {
      openSheet(`<h3>${t('updAvail')}</h3><div class="meta">${t('version')} 1.0.${latest}</div>
        <div class="notes">${esc((j.body || '').slice(0, 600))}</div><div class="meta">${t('updHint')}</div>
        <div class="act"><button class="btn ghost" data-act="sheetclose">${t('later')}</button><button class="btn" data-act="doupd" data-url="${esc(asset.browser_download_url)}">${ic('down')}${t('updNow')}</button></div>`);
    } else if (manual) toast(t('upToDate'));
  } catch (e) { if (manual) toast(t('updFail')); }
}

/* ---------- events ---------- */
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const d = el.dataset;
  switch (d.act) {
    case 'tab': setTab(d.tab); break;
    case 'pick': $('file').click(); break;
    case 'openrec': { const r = findRec(d.path); if (r) openPdf({ path: r.path, name: r.name, size: r.size }); break; }
    case 'openfile': { const f = F.view[+d.i]; if (f) openPdf({ path: f.path, name: f.name, size: f.size }); break; }
    case 'recmenu': { const r = findRec(d.path); if (!r) break;
      openSheet(`<h3>${esc(title(r.name))}</h3><button class="li" data-act="recshare" data-path="${esc(r.path)}">${ic('share')}${t('share')}</button><button class="li" data-act="recdel" data-path="${esc(r.path)}">${ic('trash')}${t('remove')}</button>`); break; }
    case 'recshare': { const r = findRec(d.path); closeSheet(); if (r) shareFile(r.path, r.name); break; }
    case 'recdel': removeRec(d.path); closeSheet(); renderRecent(); break;
    case 'filemenu': { const f = F.view[+d.i]; if (f) openSheet(`<h3>${esc(title(f.name))}</h3><button class="li" data-act="fileshare" data-i="${d.i}">${ic('share')}${t('share')}</button>`); break; }
    case 'fileshare': { const f = F.view[+d.i]; closeSheet(); if (f) shareFile(f.path, f.name); break; }
    case 'allow': RS.requestAccess().catch(() => {}); break;
    case 'rescan': loadFiles(true); break;
    case 'sort': F.sort = d.k; renderFiles(); break;
    case 'set':
      if (d.key === 'theme') { setTheme(d.val); if (!$('sheetWrap').hidden) readerMenu(); else renderSettings(); }
      else if (d.key === 'lang') { settings.lang = d.val; saveSettings(); document.documentElement.lang = d.val; renderNav(); renderSettings(); }
      break;
    case 'curlsw': settings.curl = !settings.curl; saveSettings(); el.classList.toggle('on', settings.curl); break;
    case 'checkupd': checkUpdate(true); break;
    case 'doupd': Browser.open({ url: d.url }).catch(() => { window.open(d.url, '_blank'); }); closeSheet(); break;
    case 'sheetclose': closeSheet(); break;
    case 'clearhist': clearHistory(); toast(t('cleared')); renderRecent(); break;
    case 'rclose': closeReader(); break;
    case 'bm': { const m = R.rec.marks, i = m.indexOf(R.page); if (i >= 0) { m.splice(i, 1); toast(t('bmOff')); } else { m.push(R.page); toast(t('bmOn')); } persist(true); updateChrome(); break; }
    case 'rmenu': readerMenu(); break;
    case 'gopage': { const v = parseInt($('gp').value, 10); if (v) { closeSheet(); jump(v); } break; }
    case 'gomark': closeSheet(); jump(+d.p); break;
    case 'sharecur': closeSheet(); shareFile(R.rec.path, R.rec.name); break;
    case 'zoomopen': openZoom(); break;
    case 'zclose': closeZoom(); break;
    case 'zin': R.zoom = Math.min(3, R.zoom + 0.5); renderZoom(); break;
    case 'zout': R.zoom = Math.max(1.5, R.zoom - 0.5); renderZoom(); break;
    case 'zprev': zoomPage(-1); break;
    case 'znext': zoomPage(1); break;
  }
});
$('file').addEventListener('change', (e) => {
  const f = e.target.files && e.target.files[0]; e.target.value = '';
  if (f) openPdf({ file: f, name: f.name, size: f.size });
});
let rz = 0;
window.addEventListener('resize', () => {
  if (!R.open) return;
  clearTimeout(rz);
  rz = setTimeout(() => {
    const w = $('reader').clientWidth, h = $('reader').clientHeight;
    if (!w || !h || (w === R.W && h === R.H)) return;
    R.gen++; R.cache.clear(); R.pend.clear(); sizeStage(); showPage();
  }, 200);
});
CapApp.addListener('backButton', () => {
  if (!$('sheetWrap').hidden) closeSheet();
  else if (!$('zoom').hidden) closeZoom();
  else if (R.open) closeReader();
  else if (tab !== 'recent') setTab('recent');
  else CapApp.exitApp();
});
CapApp.addListener('appStateChange', ({ isActive }) => {
  if (!isActive) persist(true);
  else if (tab === 'files' && !F.granted) loadFiles(false);
});

/* ---------- init ---------- */
(async function init() {
  document.documentElement.lang = settings.lang;
  $('pickBtn').innerHTML = ic('plus');
  if (native) { try { await StatusBar.setBackgroundColor({ color: '#0a1020' }); await StatusBar.setStyle({ style: Style.Dark }); } catch (e) {} }
  renderNav(); setTab('recent');
  setTimeout(() => $('splash').classList.add('out'), 1100);
  const last = parseInt(localStorage.getItem('rd.upd') || '0', 10);
  if (native && Date.now() - last > 3 * 3600 * 1000) setTimeout(() => checkUpdate(false), 4000);
})();
